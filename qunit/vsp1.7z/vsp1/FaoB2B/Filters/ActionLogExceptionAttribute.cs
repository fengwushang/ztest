﻿using Fao.Interface.B2B;
using Fao.Service.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fao.Log;

namespace FaoB2B.Filters
{
    /// <summary>
    /// created by：yzq 2013-01-21
    /// 记录Controller中Action的异常
    /// 在需要记录异常的Action处加[ActionLogException]
    /// </summary>
    public class ActionLogExceptionAttribute : HandleErrorAttribute
    {
        public override void OnException(ExceptionContext filterContext)
        {
            //利用Log4net记录日志 


            LogHelper.LogExceRun("", filterContext.Exception);
            //int logType = 0;//日志类型
            //string logMessage = ""; //自定义记录信息

            //switch (logType)
            //{
            //    case 0:
            //        LogHelper.LogExceDB(logMessage, filterContext.Exception);
            //        break;
            //    case 1:
            //        LogHelper.LogExceRun(logMessage,filterContext.Exception);
            //        break;
            //    default:
            //        break;
            //}           

            

            base.OnException(filterContext); 
            //filterContext.Result = new RedirectResult("~/Views/Shared/Error.cshtml");
        }

    }
}