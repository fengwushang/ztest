﻿using Fao.Common;
using Fao.Interface.B2B;
using Fao.Service.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace FaoB2B.Filters
{
    /// <summary>
    /// created by：yzq 2013-02-1-20
    /// 防止重复提交操作，过滤器
    /// </summary>
    public class NoResubmitAttribute : ActionFilterAttribute
    {
        private static readonly string HttpMehotdPost = "POST";
        private static readonly string prefix = "postFlag";

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var controllerContext = filterContext.Controller.ControllerContext;
            //如果提交操作的前一个请求不是来自本站点，则不执行提交操作。
            var req = controllerContext.RequestContext.HttpContext.Request;
            if (req.HttpMethod == HttpMehotdPost && req.UrlReferrer == null)
            {
                return;
            }

            base.OnActionExecuting(filterContext);

            //后台以及商务中心没有登录的，跳转到登录页面。
            var cl = filterContext.RouteData.Values["controller"].ToString().Trim().ToLower();
            var at = filterContext.RouteData.Values["action"].ToString().Trim().ToLower();

            if (IsBackController(cl) && !IsAjax(filterContext) && string.IsNullOrEmpty(Fao.Common.HtmlHelper.GetCookieValue("AdminName")))
            {
                if (at != "login")
                {
                    filterContext.Result = new RedirectResult("/back/login");
                }
            }
            else
            {
                if (IsBackController(cl) && !IsAjax(filterContext) && !string.IsNullOrEmpty(Fao.Common.HtmlHelper.GetCookieValue("AdminName")))
                {
                    string mid = filterContext.HttpContext.Request.QueryString["mid"];
                    if (IsAudit(at) && !AuthorityArray().Contains("2"))
                    {
                        filterContext.Result = new RedirectResult(string.Format("/back/ErrorView?mid={0}&msg=2", mid));
                    }
                    if (IsMeg(at) && !AuthorityArray().Contains("1"))
                    {
                        filterContext.Result = new RedirectResult(string.Format("/back/ErrorView?mid={0}&msg=1", mid));
                    }
                }
                else
                {
                    IBaseUserService baseUserService = new BaseUserService();
                    if (IsMyController(cl) && !IsAjax(filterContext)&& baseUserService.CurrentUser() == null)
                    {
                        filterContext.Result = new RedirectResult("/login/index?returnUrl=" + Security.Encrypt(filterContext.HttpContext.Request.RawUrl));
                    }
                    else
                    {
                        if (IsLogisticController(cl) && IsLogisticAction(at) && !IsAjax(filterContext) && baseUserService.CurrentUser() == null)
                        {
                            filterContext.Result = new RedirectResult("/login/index?returnUrl=" + Security.Encrypt(filterContext.HttpContext.Request.RawUrl));
                        }
                        else
                        {
                            if (IsSmsController(cl) && !IsAjax(filterContext) && baseUserService.CurrentUser() == null)
                            {
                                filterContext.Result = new RedirectResult("/login/index?returnUrl=" + Security.Encrypt(filterContext.HttpContext.Request.RawUrl));
                            }
                        }
                    }
                }

            }

        }

        public override void OnResultExecuted(ResultExecutedContext filterContext)
        {
            base.OnResultExecuted(filterContext);
            //if (!filterContext.IsChildAction && !(filterContext.Result is RedirectResult))
            //{
            //    //string format = "<script type='text/javascript'>$(function () [[ $('form').each(function()[[$('<input type=hidden id={0} name={0} value={1} />').appendTo($(this));]])]]); </script>";
            //    string format = "<script type='text/javascript'> var forms = document.getElementsByTagName('form'); for(var i = 0; i<forms.length; i++)[[var ele = document.createElement('input'); ele.type='hidden'; ele.id=ele.name='{0}'; ele.value='{1}'; forms[i].appendChild(ele);]] </script>";
            //    string script = string.Format(format, nameWithRoute, filterContext.HttpContext.Session[nameWithRoute]).Replace("[[", "{").Replace("]]", "}");
            //    filterContext.HttpContext.Response.Write(script);
            //}
        }

        #region 自定义

        /// <summary>
        /// 判断是否后台连接
        /// </summary>
        /// <param name="clrName"></param>
        /// <returns></returns>
        private bool IsMyController(string clrName)
        {
            string[] myClrs = { "my" };
            if (myClrs.Contains(clrName))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        /// <summary>
        /// 判断是否后台连接
        /// </summary>
        /// <param name="clrName"></param>
        /// <returns></returns>
        private bool IsLogisticController(string clrName)
        {
            string[] myClrs = { "logistic" };
            if (myClrs.Contains(clrName))
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        private bool IsLogisticAction(string at)
        {
            string[] ats = { "storeindex", "cargoindex", "vehiclesourceindex", "routeindex" };
            return ats.Contains(at);
        }
        /// <summary>
        /// 判断是否后台连接
        /// </summary>
        /// <param name="clrName"></param>
        /// <returns></returns>
        private bool IsBackController(string clrName)
        {
            string[] backClrs = { "back" };
            if (backClrs.Contains(clrName))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        /// <summary>
        /// 判断是否为Sms
        /// </summary>
        /// <param name="clrName"></param>
        /// <returns></returns>
        private bool IsSmsController(string clrName)
        {
            string[] smsClrs = { "sms" };
            if (smsClrs.Contains(clrName))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        private bool IsAjax(ActionExecutingContext filterContext)
        {

            return filterContext.HttpContext.Request.IsAjaxRequest();
        }
        /// <summary>
        /// 判断是否为审核请求
        /// </summary>
        /// <param name="at"></param>
        /// <returns></returns>
        private bool IsAudit(string at)
        {
            string[] atAs = { "ent", "b2binfoauditing", "cargoauditing", "routeauditing", "storeauditing", "vehicleauditing", "vehiclesourceauditing", "hotword", "hotwordprice", "ppc" };
            return atAs.Contains(at);
        }

        private bool IsMeg(string at)
        {
            string[] atMs = { "area", "ind", "dictionary", "category", "admin", "log" };
            return atMs.Contains(at);
        }

        private string[] AuthorityArray()
        {
            IBaseAdminService baseAdminService = new BaseAdminService();
            string adminId = Fao.Common.HtmlHelper.GetCookieValue("AdminID");
            var admin = baseAdminService.GetBaseAdminByID(adminId);
            return Fao.Common.Utils.Split(admin.VarAuthority);
        }

        
        #endregion
    }
}