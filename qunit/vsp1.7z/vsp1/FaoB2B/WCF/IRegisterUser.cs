﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Fao.Data.B2B.VM;

namespace FaoB2B.WCF
{
    // 注意: 使用“重构”菜单上的“重命名”命令，可以同时更改代码和配置文件中的接口名“IRegisterUser”。
    [ServiceContract]
    public interface IRegisterUser
    {
        [OperationContract]
        /// <summary>
        /// 注册一个用户到本平台
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        string AddUser(string user);

        /// <summary>
        /// 插入到平台表中其他平台用户 2个
        /// </summary>
        [OperationContract]
        int InsertOtherPlatform(string str);

        /// <summary>
        /// 其他平台 验证登录 数据
        /// </summary>
        /// <param name="IntTypeID">平台标识：1 ps，2 HR</param>
        /// <param name="userID">要登录平台的UserID</param>
        /// <param name="VarTokenID">验证码</param>
        /// <returns></returns>
        [OperationContract]
        int CheckToken(int IntTypeID, int userID, string VarTokenID);


        /// <summary>
        /// 修改EMail or Phone 
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="MailOrPhone"></param>
        /// <returns></returns>
        [OperationContract]
        string ChangeMailOrPhone(string uid, string MailOrPhone);

    }
}
