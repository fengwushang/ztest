﻿using Fao.Common;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace FaoB2B.WCF
{
    /// <summary>
    /// BtoB热词
    /// </summary>
    public class HotWordService : IHotWordService
    {
        public string GetHotWord(string type,string count)
        {
            StringBuilder sbXml = new StringBuilder();

            string sql = string.Format("select top {1} VarWord,COUNT(1) as n from HotWord where IntFlag=1 and IntWordType={0} group by VarWord order by n desc ", type, count);
            DataSet ds = Query(sql);
            if (ds != null)
            {
                if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        sbXml.AppendFormat("{0}﹩", dr["VarWord"]);
                    }
                }
            }
            if (sbXml.ToString().EndsWith("﹩"))
                sbXml = sbXml.Remove(sbXml.ToString().Length-1, 1);
            return sbXml.ToString();
        }

        //获取所有类型对应数量的热词
        public string BtoBHotWord(string count) 
        {
            StringBuilder sbXml = new StringBuilder();
            int hwcount = 0;
            int.TryParse(Utils.GetAppValueByName("HeatCount"), out hwcount);
            if (hwcount == 0)
                hwcount = 10;
            string sql = string.Format(@"select *
                                         from ( 	
	                                         select 
		                                        hw.VarWord,hw.IntWordType as Type
		                                        ,row_number() over (partition by IntWordType order by n desc) rn   
	                                         from 
	                                         (select top (5*{0}) VarWord,max(IntWordType) IntWordType,COUNT(1) as n from HotWord where IntFlag=1  group by VarWord having COUNT(1)>={1} order by n desc)
	                                          hw
                                            ) tt
                                        where tt.rn<={0}", count,hwcount);
            DataSet ds = Query(sql);
            if (ds != null)
            {
                if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        sbXml.AppendFormat("{0}¿{1}﹩", dr["VarWord"], dr["Type"]);
                    }
                }
            }
            if (sbXml.ToString().EndsWith("﹩"))
                sbXml = sbXml.Remove(sbXml.ToString().Length - 1, 1);
            return sbXml.ToString();
        }

        #region 数据操作

        public static string connectionString = ConfigurationManager.ConnectionStrings["FaoSMSDB"].ToString();

        /// <summary>
        /// 执行查询语句，返回DataSet
        /// </summary>
        /// <param name="SQLString">查询语句</param>
        /// <returns>DataSet</returns>
        public  DataSet Query(string SQLString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                DataSet ds = new DataSet();
                try
                {
                    connection.Open();
                    SqlDataAdapter command = new SqlDataAdapter(SQLString, connection);
                    command.Fill(ds, "ds");
                }
                catch (System.Data.SqlClient.SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
                return ds;
            }
        }

        #endregion
    }
}
