﻿using System.ServiceModel;
using System.ServiceModel.Channels;
using Fao.Common;
using Fao.Data.B2B.VM;
using Fao.Service.B2B;
using Fao.Interface.B2B;


namespace FaoB2B.WCF
{
    // 注意: 使用“重构”菜单上的“重命名”命令，可以同时更改代码、svc 和配置文件中的类名“RegisterUser”。
    // 注意: 为了启动 WCF 测试客户端以测试此服务，请在解决方案资源管理器中选择 RegisterUser.svc 或 RegisterUser.svc.cs，然后开始调试。
    public class RegisterUser : IRegisterUser
    {
        #region  添加引用
        IBasePlatUserService basePlatUserService = new BasePlatUserService();

        #endregion
        /// <summary>
        /// 注册一个用户到B2B平台
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public string AddUser(string user)
        {
            if (!CheckEndPoitIP())
                return "0";        //非法调用

            string[] str = user.Split(',');
            VmBasePlatUser baseUser = new VmBasePlatUser();
            baseUser.VarPhone = str[0];
            baseUser.IntPhoneVerify = str[1];
            baseUser.VarEmail = str[2];
            baseUser.IntEmailVerify = str[3];
            baseUser.VarEmailVerifyCode = str[4];
            baseUser.DteEmailVerifyValid = str[5];
            baseUser.VarRealName = str[6];
            baseUser.VarNickName = str[7];
            baseUser.VarPWD = str[8];
            baseUser.IntUserGroup = str[9];
            baseUser.IntUserID = str[10];

            int result = basePlatUserService.AddRegisterUserWcf(baseUser);

            return result.ToString();
        }

        /// <summary>
        /// 插入到平台表中其他平台用户 2个
        /// </summary>
        /// <param name="str">'114,1.2,123.321'</param>
        public int InsertOtherPlatform(string str)
        {
            return basePlatUserService.InsertOtherPlatform(str);
        }

        /// <summary>
        /// 其他平台 验证登录 数据
        /// </summary>
        /// <param name="IntTypeID">平台标识：1 PS，2 HR</param>
        /// <param name="userID">要登录平台的UserID</param>
        /// <param name="VarTokenID">验证码</param>
        /// <returns></returns>
        public int CheckToken(int IntTypeID, int userID, string VarTokenID)
        {
            int re = 0;
            if (!CheckEndPoitIP())
                return re;        //非法调用

            //此处判断数据库,如果存在返回真，并将该条数据Ingflag=0
            //获取用户是否存在
            int checkUser = basePlatUserService.GetPlatUser(IntTypeID, userID, VarTokenID);

            if (checkUser > 0)
            {
                //删除联合登录表信息
                basePlatUserService.DelPlatUser(IntTypeID, userID, VarTokenID);
                re = 1;
            }
            else
            {
                re = 0;
            }

            return re;
        }


        /// <summary>
        /// 修改EMail or Phone 
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="MailOrPhone"></param>
        /// <returns></returns> 
        public string ChangeMailOrPhone(string uid, string MailOrPhone)
        {
            IBaseUserService baseUserService = new BaseUserService();
            return baseUserService.UpdateUserMail(Utils.ToInt(uid), MailOrPhone);
        }

        /// <summary>
        ///  判断调用WCF是否授权的客户端
        /// </summary>
        /// <returns></returns>
        public bool CheckEndPoitIP()
        {
            OperationContext context = OperationContext.Current;
            MessageProperties properties = context.IncomingMessageProperties;
            RemoteEndpointMessageProperty endpoint = properties[RemoteEndpointMessageProperty.Name] as RemoteEndpointMessageProperty;
            string ip = endpoint.Address;
            if (ip.Equals("::1"))
                ip = "127.0.0.1";
            if (Utils.GetAppValueByName("IPAddress").Contains(ip))
                return true;
            else
                return false;
        }
    }
}
