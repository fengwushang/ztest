﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace FaoB2B.WCF
{
    /// <summary>
    /// BtoB热词
    /// </summary>
    [ServiceContract]
    public interface IHotWordService
    {
        [OperationContract]
        string GetHotWord(string type,string count);

        //获取所有类型对应数量的热词
        [OperationContract]
        string BtoBHotWord(string count); 
    }
}
