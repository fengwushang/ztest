﻿using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using Fao.Service.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fao.Common;
using FaoB2B.Filters;

namespace FaoB2B.Controllers
{
    /// <summary>
    /// created by：mbx 2013-02-28
    /// 电商信息（供求招代合）控制器
    /// </summary>
    public class B2BInfoController : Controller
    {
        #region 引用的服务

        IB2BInfoService b2BInfoService = new B2BInfoService();

        IPPCService ppcService = new PPCService();

        #endregion


        #region 供应

        //供应信息预览
        [ActionLogException]
        public ActionResult Sell(string id, string ppc)
        {
            int infoID = Utils.ToInt(Security.Decrypt(id));
            var b2bInfo = b2BInfoService.GetB2BInfoByID(infoID);
            b2BInfoService.UpdateBrowserCount(b2bInfo);
            if (!string.IsNullOrWhiteSpace(ppc))
            {
                try
                {
                    //扣除竞价费用
                    ppcService.DeductionForExpenses(ppc);

                }
                catch
                {
                    //执行扣费操作，不阻断其他操作 
                }
            }
            
            return View(b2bInfo);
        }
        #endregion


        #region 求购

        //求购信息预览
        [ActionLogException]
        public ActionResult Buy(string id,string ppc,string t)
        {
            int infoID = Utils.ToInt(Security.Decrypt(id));
            var b2bInfo = b2BInfoService.GetB2BInfoByID(infoID);
            b2BInfoService.UpdateBrowserCount(b2bInfo);
            if (!string.IsNullOrWhiteSpace(ppc))
            {
                try
                {
                    //扣除竞价费用
                    ppcService.DeductionForExpenses(ppc);

                }
                catch
                {
                    //执行扣费操作，不阻断其他操作 
                }
            }
            
            ViewBag.Type = t;
            if (string.IsNullOrEmpty(b2bInfo.PriceAsk))
                b2bInfo.PriceAsk = "面议";
            if (string.IsNullOrEmpty(b2bInfo.Specifications))
                b2bInfo.Specifications = "不限";
            if (string.IsNullOrEmpty(b2bInfo.Packagingrequire))
                b2bInfo.Packagingrequire = "不限";
            return View(b2bInfo);
        }
        #endregion


        #region 招商

        //招商信息预览
        [ActionLogException]
        public ActionResult Invest(string id,string ppc)
        {
            int infoID = Utils.ToInt(Security.Decrypt(id));
            var b2bInfo = b2BInfoService.GetB2BInfoByID(infoID);
            b2BInfoService.UpdateBrowserCount(b2bInfo);
            if (!string.IsNullOrWhiteSpace(ppc))
            {
                try
                {
                    //扣除竞价费用
                    ppcService.DeductionForExpenses(ppc);

                }
                catch
                {
                    //执行扣费操作，不阻断其他操作 
                }
            }
            
            return View(b2bInfo);
        }
        #endregion


        #region 代理

        //代理信息预览
        [ActionLogException]
        public ActionResult Proxy(string id,string ppc)
        {
            int infoID = Utils.ToInt(Security.Decrypt(id));
            var b2bInfo = b2BInfoService.GetB2BInfoByID(infoID);
            b2BInfoService.UpdateBrowserCount(b2bInfo);
            if (!string.IsNullOrWhiteSpace(ppc))
            {
                try
                {
                    //扣除竞价费用
                    ppcService.DeductionForExpenses(ppc);

                }
                catch
                {
                    //执行扣费操作，不阻断其他操作 
                }
            }
            
            return View(b2bInfo);
        }
        #endregion


        #region 合作

        //合作信息预览
        [ActionLogException]
        public ActionResult Cooperate(string id,string ppc)
        {
            int infoID = Utils.ToInt(Security.Decrypt(id));
            var b2bInfo = b2BInfoService.GetB2BInfoByID(infoID);
            b2BInfoService.UpdateBrowserCount(b2bInfo);
            if (!string.IsNullOrWhiteSpace(ppc))
            {
                try
                {
                    //扣除竞价费用
                    ppcService.DeductionForExpenses(ppc);

                }
                catch
                {
                    //执行扣费操作，不阻断其他操作 
                }
            }
            
            return View(b2bInfo);
        }
        #endregion
    }
}
