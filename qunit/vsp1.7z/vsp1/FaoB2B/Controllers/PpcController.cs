﻿using Fao.Common;
using Fao.Data.B2B;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.Enum;
using Fao.Interface.B2B;
using FaoB2B.Filters;
using Fao.Service.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fao.Data.B2B.VM;

namespace FaoB2B.Controllers
{
    /// <summary>
    /// created by：chf 2013-2-27 10:03:22
    /// 排名推广 控制器
    /// </summary>
    public class PpcController : Controller
    { 
        IHotWordService hotWordService = new HotWordService();
        IPPCService ppcService = new PPCService();
        IHotWordPriceService hotWordPriceService = new HotWordPriceService();
        IUserTransactionService userTransactionService = new UserTransactionService();
        IPPCService pPCService = new PPCService();
        public ActionResult HotWord()
        { 
            return View();
        }

        //返回当月每类检索热词及其排名
        [ActionLogException]
        [HttpPost]
        public ContentResult HotWordList(int id)
        {
            var hotlist = hotWordService.GetHotWords(id);
            return Content(Utils.ToJsonStr(hotlist));
        }

       
        /// <summary>
        /// 得到该热词，每类数据的起步价
        /// </summary>
        /// <param name="id"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult HotWordPrice(string id )
        {
            var hotwordPriceSet = hotWordPriceService.GetOneHotWordPrices(id);
            ViewData["DecStartPrice1"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == 1).DecStartPrice;
            ViewData["DecStartPrice2"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == 2).DecStartPrice;
            ViewData["DecStartPrice3"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == 3).DecStartPrice;
            ViewData["DecStartPrice4"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == 4).DecStartPrice;
            ViewData["DecStartPrice5"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == 5).DecStartPrice;
            ViewData["DecStartPrice6"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == 6).DecStartPrice;
            ViewData["DecStartPrice7"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == 7).DecStartPrice;
            ViewData["DecStartPrice8"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == 8).DecStartPrice;
            ViewData["DecStartPrice9"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == 9).DecStartPrice;

            ViewBag.Key = id;
            return View();
        }

        /// <summary>
        /// 返回用户所出的关键词当前的竞价状况
        /// </summary>
        /// <param name="id">信息类型</param> 
        /// <returns>关键字</returns>
        [ActionLogException]
        [HttpPost]
        public ContentResult HotWordPriceHistory(string id, string type)
        { 
            var hotprices = ppcService.GetOneHotWordHistory(id, type);
            return Content(Utils.ToJsonStr(hotprices));
        }

        /// <summary>
        /// 当前登录用户开始竞价
        /// </summary>
        /// <param name="id">信息类型</param>
        /// <param name="type">关键字</param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult HotWordPPC(string id="", string type=null)
        {
            if (id == "")
            {
                return Redirect("/PPC/HotWord");
            }
            int intID = int.Parse(id);
            ViewData["InfoType"] = Enum.GetName(typeof(EnumInfoType), intID);
            ViewData["TypeID"] = intID;
            ViewData["KeyWord"] = type;
            var hotwordPriceSet = hotWordPriceService.GetOneHotWordPrices(type);
            ViewData["DecStartPrice"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == intID).DecStartPrice;
            ViewData["DecStepPrice"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == intID).DecStepPrice;
            var e = userTransactionService.GetCurrentUserTransaction();

            if(e!=null)
            {
                ViewData["PPCBalance"] = e.PPCBalance;
            }
            return View();
        }

        /// <summary>
        /// 添加竞价
        /// </summary>
        /// <returns></returns>
        [ActionLogException,HttpPost]
        public ActionResult HostWordPPC()
        {
            var paPwd = Request.Form["paPwd"];
            var infoID = Request.Form["infoID"];
            var bidden = Request.Form["bidden"];
            var count = Request.Form["count"];
            var SelectTime=Request.Form["SelectTime"];
            var type=Request.Form["InfoType"];
            var Ip = Request.UserHostAddress;
            var keyWord = Request.Form["KeyWord"];
            List<string> error = new List<string>();

            #region 验证
            
            if (string.IsNullOrWhiteSpace(bidden))
            {
                error.Add("请输入出价");
            }
            else
            {
                decimal Dbidden = 0;
                if (!decimal.TryParse(bidden, out Dbidden))
                {
                    error.Add("请输入正确的价格");
                }
            }

            List<Tuple<string, string>> list = new List<Tuple<string, string>>();
            if (string.IsNullOrWhiteSpace(count))
            {
                error.Add("请选择生效时段");
            }
            if (string.IsNullOrWhiteSpace(infoID))
            {
                error.Add("请选择竞价信息");
            }
            if (string.IsNullOrWhiteSpace(paPwd))
            {
                error.Add("请输入支付密码");
            }

            else
            {
                for (int i = 1; i <= int.Parse(count); i++)
                {
                    var s = Request.Form["StartTime"+i.ToString()];
                    var e = Request.Form["EndTime"+i.ToString()];
                    if ((!string.IsNullOrWhiteSpace(s)) && (!string.IsNullOrWhiteSpace(e)))
                    {
                        list.Add(new Tuple<string, string>(s, e));
                    }
                }
            }
            if (list.Count == 0)
            {
                error.Add("请选择生效时段");
            }
            string strID = Security.Decrypt(infoID);
            int id = 0;
            if (!int.TryParse(strID, out id))
            {
                error.Add("信息不存在");
            }

            #endregion

            if (error.Count > 0)
            {
                return Content(Utils.ToJsonStr(error.First()));
            }

            VmPPC model = new VmPPC() { 
                DteValid=DateTime.Now.AddMonths(int.Parse(SelectTime)),
                DecValue=decimal.Parse(bidden),
                IntTablePrimkeyID=id,
                IntWordType=int.Parse(type),
                VarKeyword=keyWord,
            };

            string flag=pPCService.AddPPC(model, list,paPwd);
            if (flag != "1")
            {
                error.Add(flag);
            }
            if (error.Count > 0)
            {
                return Content(Utils.ToJsonStr(error));
            }
            return Content("1");
        }

        /// <summary>
        /// 修改PPC
        /// </summary>
        /// <param name="EncriptID"></param>
        /// <returns></returns>
        public ActionResult EditPPC(string EncriptID)
        {
            var model=ppcService.GetPPCByID(EncriptID);

            ViewData["InfoType"] = Enum.GetName(typeof(EnumInfoType), model.IntWordType);
            ViewData["TypeID"] = model.IntWordType;
            ViewData["KeyWord"] = model.VarKeyword;
            var hotwordPriceSet = hotWordPriceService.GetOneHotWordPrices(model.VarKeyword);
            ViewData["DecStartPrice"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == model.IntWordType).DecStartPrice;
            ViewData["DecStepPrice"] = hotwordPriceSet.SingleOrDefault(d => d.IntWordType == model.IntWordType).DecStepPrice;
            var e = userTransactionService.GetCurrentUserTransaction();

            if (e != null)
            {
                ViewData["PPCBalance"] = e.PPCBalance;
            }
            return View(model);
        }

        /// <summary>
        /// 竞价列表面
        /// </summary>
        /// <returns></returns>
        public ActionResult PPCIndex(string state="1")
        {
            ViewBag.state = state;
            return View();
        }

        /// <summary>
        /// 得到竞价列表数据
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetPPCPager(SmPPC sm, int page, int rows)
        {
            var pager = ppcService.GetPPCPager(sm, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 改变竞价状态
        /// </summary>
        /// <param name="state"></param>
        /// <param name="eid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult SetState(int state, string eid)
        {
            string flag = ppcService.ChangeFlag(state, eid);

            return Content(flag);
        }

        /// <summary>
        /// 对推广账号充值
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult RechangePPC()
        {
            var e = userTransactionService.GetCurrentUserTransaction();
            ViewData["Money"] = e.AccountBalance;
            ViewData["PPCMoney"] = e.PPCBalance;
            return View();
        }

        /// <summary>
        /// 对推广账号充值
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        [HttpPost]
        public ActionResult RechangePPC(string paPwd, string Rechange)
        {
            string msg = "";
            decimal money = 0.0M;
            if (paPwd == "")
            {
                msg= "请填写支付密码";
            }
            else if (Rechange == "")
            {
                msg= "请填写充值金额";
            } 
            else if (!decimal.TryParse(Rechange, out money))
            {
                msg= "请填写正确的充值金额";
            }
            else
            {
                var e = userTransactionService.GetCurrentUserTransaction();
                if (e.AccountBalance < money)
                {
                    msg = "账号余额不足";
                }
                else
                {
                    msg=userTransactionService.PPCRechange(paPwd, money);
                }
            }
            return Content(msg);
        }
    }
}
