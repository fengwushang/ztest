﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using Fao.Service.B2B;
using FaoB2B.Filters;
using Fao.Common;
using System.Configuration;
using Fao.Data.B2B.Enum;

namespace FaoB2B.Controllers
{
    /// <summary>
    /// created by：yzq 2013-02-19
    /// 物流 四类信息控制器
    /// </summary>
    public class LogisticController : Controller
    {
        #region 引用的服务

        ILogisticCargoService logisticCargoService = new LogisticCargoService();
        ILogisticVehicleService logisticVehicleService = new LogisticVehicleService();
        ILogisticStoreService logisticStoreService = new LogisticStoreService();
        ILogisticVehicleSourceService logisticVehicleSourceService = new LogisticVehicleSourceService();
        ILogisticRouteService logisticRouteService = new LogisticRouteService();
        IBaseDictionaryService baseDictionary = new BaseDictionaryService();
        IAttachmentService attachmentService = new AttachmentService();
        IEnterpriseService enterpriseService = new EnterpriseService();
        IHotWordService hotwordService = new HotWordService();
        IPPCService ppcService = new PPCService();

        #endregion

        public ActionResult Index()
        {
            return View();
        }


        /// <summary>
        /// 记录物流检索的热词
        /// </summary>
        /// <param name="id">类型 6货源，7库源，8,车源，9物流专线</param>
        /// <param name="keyword">热词</param>
        private void RecordHotWord(string id, string keyword)
        {
            if (!string.IsNullOrEmpty(id) && !string.IsNullOrEmpty(keyword))
            {
                hotwordService.AddHotWord(id, HttpUtility.UrlDecode(keyword));
            }
        }


        #region 物流前端 列表页面
        //货源视图
        public ActionResult Cargo()
        {
            return View();
        }

        //获取货源数据，记录热词
        [ActionLogException]
        public ContentResult GetCargo(SmLogisticCargo smModel, int page, int rows)
        {
            if (smModel.SeFlag == "0")
                RecordHotWord("6", smModel.KeyWord);
            var json = logisticCargoService.GetLogisticCargosWithPage(smModel, page, rows);
            return Content(Utils.ToJsonStr(json));
        } 

        //库源视图
        public ActionResult Store()
        {
            return View();
        }
  
        //获取库源数据，记录热词
        [ActionLogException]
        public ContentResult GetStore(SmLogisticStore smModel, int page, int rows)
        {
            if (smModel.SeFlag == "0")
                RecordHotWord("7", smModel.KeyWord);
            var json = logisticStoreService.GetLogisticStoreWithPage(smModel, page, rows);
            return Content(Utils.ToJsonStr(json));
        }


        //车源视图
        public ActionResult VehicleSource()
        {
            return View();
        }

  
        //获取车源数据,记录热词
        [ActionLogException]
        public ContentResult GetVehicleSource(SmLogisticVehicleSource smModel, int page, int rows)
        {
            if (smModel.SeFlag == "0")
                RecordHotWord("8", smModel.KeyWord);
            var json = logisticVehicleSourceService.GetLogisticVehicleSourcesWithPage(smModel, page, rows);
            return Content(Utils.ToJsonStr(json));
        }

        //物流专线视图
        public ActionResult Route()
        {
            return View();
        }
  
        //获取物流专线数据，记录热词
        [ActionLogException]
        public ContentResult GetRoute(SmLogisticRoute smModel, int page, int rows)
        {
            if (smModel.SeFlag == "0")
                RecordHotWord("9", smModel.KeyWord);
            var json = logisticRouteService.GetLogisticRouteWithPage(smModel, page, rows);
            return Content(Utils.ToJsonStr(json));
        }
        #endregion


        #region 物流前端 详细页面
        //货源
        [ActionLogException]
        public ActionResult CargoInfo(string id,string ppc)
        {
            if (!string.IsNullOrWhiteSpace(ppc))
            {
                try
                {
                    //扣除竞价费用
                    ppcService.DeductionForExpenses(ppc);
                }
                catch
                {
                    //执行扣费操作，不阻断其他操作 
                }
            }
            var model = logisticCargoService.GetLogisticCargoByID(id);
            if (model.TransAsk == "没选" || string.IsNullOrEmpty(model.TransAsk))
                model.TransAsk = "无";
            logisticCargoService.UpdateBrowserCount(model);
            return View(model);
        }

        //库源
        [ActionLogException]
        public ActionResult StoreInfo(string id, string ppc)
        {
            try
            {
                //扣除竞价费用
                ppcService.DeductionForExpenses(ppc);
            }
            catch
            {
                //执行扣费操作，不阻断其他操作 
            }
            var model = logisticStoreService.GetLogisticStoreByID(id);
            logisticStoreService.UpdateBrowserCount(model);
            return View(model);
        }

        //车源
        [ActionLogException]
        public ActionResult VehicleSourceInfo(string id, string ppc)
        {
            try
            {
                //扣除竞价费用
                ppcService.DeductionForExpenses(ppc);
            }
            catch
            {
                //执行扣费操作，不阻断其他操作 
            }
            var model = logisticVehicleSourceService.GetLogisticVehicleSourceByID(id);
            logisticVehicleSourceService.UpdateBrowserCount(model);
            return View(model);
        }

        //物流专线
        [ActionLogException]
        public ActionResult RouteInfo(string id, string ppc)
        {
            try
            {
                //扣除竞价费用
                ppcService.DeductionForExpenses(ppc);
            }
            catch
            {
                //执行扣费操作，不阻断其他操作 
            }
            var model = logisticRouteService.GetLogisticRouteByID(id);
            logisticRouteService.UpdateBrowserCount(model);
            return View(model);
        }

        //获取图片集合
        [ActionLogException]
        public ContentResult GetAlbum(string id, int tableID)
        {
            int aid = Utils.ToInt(Security.Decrypt(id));
            var model = attachmentService.GetAttachmentsByTableAndPK(aid, tableID);
            return Content(Utils.ToJsonStr(model));
        }

        #endregion


        #region 车辆信息

        /// <summary>
        /// 添加车辆信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult AddVehicleInfo()
        {
            var enterprise = enterpriseService.GetCurrentEntInfo();
            if (enterprise == null || enterprise.EnterpriseID == 0)
            {
                return Content("<script type='text/javascript'>alert('请先完善企业信息');window.location.href='/My/EntInfo?mid=61'</script>");
            }
            else if (enterprise != null && enterprise.Flag.HasValue && enterprise.Flag == 0)
            {
                return Content("<script type='text/javascript'>alert('企业被冻结请联系管理员');history.back(-1);</script>");
            } 
            var count = this.logisticVehicleService.GetVehicleInfoCount();
            ViewBag.CountInfo = count;
            SetVehicleType();
            VmLogisticVehicle model = new VmLogisticVehicle();
            model.EncriptID = "0";
            model.ImageUrl = new List<string>() { "", "", "" };
            model.ImageID = new List<string>() { "", "", "" };
            return View(model);
        }

        /// <summary>
        /// 添加车辆信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult AddVehicleInfo(string EncriptID)
        {
            VmLogisticVehicle model = new VmLogisticVehicle();
            try{
            TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {

                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                var p = GetImageInfo();
                string flag = logisticVehicleService.AddVehicleInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 修改车辆信息
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult EditVehicleInfo(string EncryptID, string IsPerview = "")
        {
            var count = this.logisticVehicleService.GetVehicleInfoCount();
            ViewBag.CountInfo = count;
            ViewBag.IsPerview = IsPerview;
            SetVehicleType();
            var model = logisticVehicleService.GetLogisticVehicleByID(EncryptID);
            if (model != null)
            {
                if (model.ImageID == null)
                {
                    model.ImageID = new List<string>();
                    model.ImageUrl = new List<string>();
                }
                for (int i = model.ImageID.Count; i < 3; i++)
                {
                    model.ImageID.Add("");
                    model.ImageUrl.Add("");
                }

                return View("AddVehicleInfo", model);
            }
            return Content("未找到该信息!");
        }

        /// <summary>
        /// 修改车辆信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult EditVehicleInfo(bool IsPostBack = true)
        {
            VmLogisticVehicle model = new VmLogisticVehicle();
            try{
            TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                var p = GetImageInfo();
                string flag = logisticVehicleService.UpdateVehicleInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 列表页面
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult VehicleIndex(string state = "3")
        {
            var count = this.logisticVehicleService.GetVehicleInfoCount();
            ViewBag.CountInfo = count;
            ViewBag.state = state;
            return View();
        }
        /// <summary>
        /// 得到车辆列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetVehiclePager(SmLogisticVehicle search, int page, int rows)
        {
            var pager = logisticVehicleService.GetVehiclePager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 删除车辆信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult DeleteVehicle(string eid)
        {
            var vm = logisticVehicleService.GetLogisticVehicleByID(eid);
            if (vm != null)
            {
                vm.Flag = 0;
                string flag = logisticVehicleService.UpdateVehicleInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("删除失败");
                }
            }
            return Content("未提到该信息");
        }


        /// <summary>
        /// 提交车辆信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult ApproveVehicleInfo(string eid)
        {
            var vm = logisticVehicleService.GetLogisticVehicleByID(eid);
            if (vm != null)
            {
                if ((!vm.Flag.HasValue) || vm.Flag != 1)
                {
                    return Content("该信息不能提交");
                }
                else
                {
                    vm.Flag = 2;
                    string flag = logisticVehicleService.UpdateVehicleInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("提交失败");
                    }
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 得到车辆统计信息
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult GetVehicleCount()
        {
            var count = this.logisticVehicleService.GetVehicleInfoCount();
            return Content(Utils.ToJsonStr(count));
        }

        /// <summary>
        /// 车源批量操作
        /// </summary>
        /// <param name="type"></param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult VehicleBatch(int type, string chooses = "")
        {
            string flag = logisticVehicleService.VehicleBatch(type, chooses);
            return Content(flag);
        }
        #endregion

        #region 车源信息

        /// <summary>
        /// 添加车源信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult AddVehicleSourceInfo()
        {
            var enterprise = enterpriseService.GetCurrentEntInfo();
            if (enterprise == null || enterprise.EnterpriseID == 0)
            {
                return Content("<script type='text/javascript'>alert('请先完善企业信息');window.location.href='/My/EntInfo?mid=61'</script>");
            }
            else if (enterprise != null && enterprise.Flag.HasValue && enterprise.Flag == 0)
            {
                return Content("<script type='text/javascript'>alert('企业被冻结请联系管理员');history.back(-1);</script>");
            } 
            var count = this.logisticVehicleSourceService.GetVehicleSourceInfoCount();
            ViewBag.CountInfo = count;
            SetVehicle();
            VmLogisticVehicleSource model = new VmLogisticVehicleSource();
            model.VehicleSourceID = "0";
            model.ImageUrl = new List<string>() { "", "", "" };
            model.ImageID = new List<string>() { "", "", "" };
            return View(model);
        }

        /// <summary>
        /// 添加车辆信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult AddVehicleSourceInfo(string EncriptID)
        {
            VmLogisticVehicleSource model = new VmLogisticVehicleSource();
            try{
            TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                var p = GetImageInfo();
                string flag = logisticVehicleSourceService.AddVechicleSourceInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 修改车源信息
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult EditVehicleSourceInfo(string EncryptID, string IsPerview = "")
        {
            var count = this.logisticVehicleSourceService.GetVehicleSourceInfoCount();
            ViewBag.CountInfo = count;
            ViewBag.IsPerview = IsPerview;
            SetVehicle();
            var model = logisticVehicleSourceService.GetVehicleSourceInfoBy(EncryptID);
            if (model != null)
            {
                if (model.ImageID == null)
                {
                    model.ImageID = new List<string>();
                    model.ImageUrl = new List<string>();
                }
                for (int i = model.ImageID.Count; i < 3; i++)
                {
                    model.ImageID.Add("");
                    model.ImageUrl.Add("");
                }

                return View("AddVehicleSourceInfo", model);
            }
            return Content("未找到该信息!");
        }

        /// <summary>
        /// 修改车源信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult EditVehicleSourceInfo(bool IsPostBack = true)
        {
            VmLogisticVehicleSource model = new VmLogisticVehicleSource();
            try{
            TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                var p = GetImageInfo();
                string flag = logisticVehicleSourceService.UpdateVehicleSourceInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 列表页面
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult VehicleSourceIndex(string state = "3")
        {
            var count = this.logisticVehicleSourceService.GetVehicleSourceInfoCount();
            ViewBag.CountInfo = count;
            ViewBag.state = state;
            return View();
        }

        /// <summary>
        /// 得到车源列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetVehicleSourcePager(SmLogisticVehicleSource search, int page, int rows)
        {
            var pager = logisticVehicleSourceService.GetVehicleSourcePager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 删除车源信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult DeleteVehicleSource(string eid)
        {
            var vm = logisticVehicleSourceService.GetVehicleSourceInfoBy(eid);
            if (vm != null)
            {
                vm.Flag = 0;
                string flag = logisticVehicleSourceService.UpdateVehicleSourceInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("删除失败");
                }
            }
            return Content("未提到该信息");
        }
        [ActionLogException]
        public ActionResult RefreshVehicleSourceInfo(string eid)
        {
            var vm = logisticVehicleSourceService.GetVehicleSourceInfoBy(eid);
            if (vm != null)
            {
                vm.RefreshDate = DateTime.Now;
                string flag = logisticVehicleSourceService.UpdateVehicleSourceInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("刷新失败");
                }
            }
            return Content("未提到该信息");
        }
        /// <summary>
        /// 提交车源信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult ApproveVehicleSourceInfo(string eid)
        {
            var vm = logisticVehicleSourceService.GetVehicleSourceInfoBy(eid);
            if (vm != null)
            {
                if ((!vm.Flag.HasValue) || vm.Flag != 1)
                {
                    return Content("该信息不能提交");
                }
                else
                {
                    vm.Flag = 2;
                    string flag = logisticVehicleSourceService.UpdateVehicleSourceInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("提交失败");
                    }
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 得到车辆统计信息
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult GetVehicleSourceCount()
        {
            var count = this.logisticVehicleSourceService.GetVehicleSourceInfoCount();
            return Content(Utils.ToJsonStr(count));
        }

        /// <summary>
        /// 车源批量操作
        /// </summary>
        /// <param name="type"></param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult VehicleSourceBatch(int type, string chooses = "")
        {
            string flag = logisticVehicleSourceService.VehicleSourceBatch(type, chooses);
            return Content(flag);
        }
        #endregion

        #region 仓库信息

        /// <summary>
        /// 添加仓库信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult AddStoreInfo()
        {
            var enterprise = enterpriseService.GetCurrentEntInfo();
            if (enterprise == null || enterprise.EnterpriseID == 0)
            {
                return Content("<script type='text/javascript'>alert('请先完善企业信息');window.location.href='/My/EntInfo?mid=61'</script>");
            }
            else if (enterprise != null && enterprise.Flag.HasValue && enterprise.Flag == 0)
            {
                return Content("<script type='text/javascript'>alert('企业被冻结请联系管理员');history.back(-1);</script>");
            }
            var count = this.logisticStoreService.GetLogisticStoreInfoCount();
            ViewBag.CountInfo = count;

            VmLogisticStore model = new VmLogisticStore();
            model.EncriptID = "0";
            model.ImageUrl = new List<string>() { "", "", "" };
            model.ImageID = new List<string>() { "", "", "" };
            return View(model);
        }

        /// <summary>
        /// 添加仓库信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult AddStoreInfo(string EncriptID)
        {
            VmLogisticStore model = new VmLogisticStore();
            try{
            TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                var p = GetImageInfo();
                string flag = logisticStoreService.AddLogisticStoreInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 修改仓库信息
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult EditStoreInfo(string EncryptID, string IsPerview = "")
        {
            var count = this.logisticStoreService.GetLogisticStoreInfoCount();
            ViewBag.CountInfo = count;
            ViewBag.IsPerview = IsPerview;
            var model = logisticStoreService.GetLogisticStoreInfoBy(EncryptID);
            if (model != null)
            {
                if (model.ImageID == null)
                {
                    model.ImageID = new List<string>();
                    model.ImageUrl = new List<string>();
                }
                for (int i = model.ImageID.Count; i < 3; i++)
                {
                    model.ImageID.Add("");
                    model.ImageUrl.Add("");
                }

                return View("AddStoreInfo", model);
            }
            return Content("未找到该信息!");
        }

        /// <summary>
        /// 修改仓库信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult EditStoreInfo(bool IsPostBack = true)
        {
            VmLogisticStore model = new VmLogisticStore();
            try{
            TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                var p = GetImageInfo();
                string flag = logisticStoreService.UpdateLogisticStoreInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 列表页面
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult StoreIndex(string state = "3")
        {
            var count = this.logisticStoreService.GetLogisticStoreInfoCount();
            ViewBag.CountInfo = count;
            ViewBag.state = state;
            return View();
        }

        /// <summary>
        /// 得到仓库列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetStorePager(SmLogisticStore search, int page, int rows)
        {
            var pager = logisticStoreService.GetLogisticStorePager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 删除仓库信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult DeleteStore(string eid)
        {
            var vm = logisticStoreService.GetLogisticStoreInfoBy(eid);
            if (vm != null)
            {
                vm.Flag = 0;
                string flag = logisticStoreService.UpdateLogisticStoreInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("删除失败");
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 刷新创新信息
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult RefreshStoreInfo(string eid)
        {
            var vm = logisticStoreService.GetLogisticStoreInfoBy(eid);
            if (vm != null)
            {
                vm.RefreshDate = DateTime.Now;
                string flag = logisticStoreService.UpdateLogisticStoreInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("刷新失败");
                }
            }
            return Content("未提到该信息");
        }
        /// <summary>
        /// 提交仓库信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult ApproveStoreInfo(string eid)
        {
            var vm = logisticStoreService.GetLogisticStoreInfoBy(eid);
            if (vm != null)
            {
                if ((!vm.Flag.HasValue) || vm.Flag != 1)
                {
                    return Content("该信息不能提交");
                }
                else
                {
                    vm.Flag = 2;
                    string flag = logisticStoreService.UpdateLogisticStoreInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("提交失败");
                    }
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 得到仓库统计信息
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult GetStoreCount()
        {
            var count = this.logisticStoreService.GetLogisticStoreInfoCount();
            return Content(Utils.ToJsonStr(count));
        }

        /// <summary>
        /// 仓库批量操作
        /// </summary>
        /// <param name="type"></param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult StoreBatch(int type, string chooses = "")
        {
            string flag = logisticStoreService.StoreBatch(type, chooses);
            return Content(flag);
        }

        #endregion

        #region 货源信息

        /// <summary>
        /// 添加货源信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult AddCargoInfo()
        {
            var enterprise = enterpriseService.GetCurrentEntInfo();
            if (enterprise == null || enterprise.EnterpriseID == 0)
            {
                return Content("<script type='text/javascript'>alert('请先完善企业信息');window.location.href='/My/EntInfo?mid=61'</script>");
            }
            else if (enterprise != null && enterprise.Flag.HasValue && enterprise.Flag == 0)
            {
                return Content("<script type='text/javascript'>alert('企业被冻结请联系管理员');history.back(-1);</script>");
            }
            var count = this.logisticCargoService.GetLogisticCargoInfoCount();
            ViewBag.CountInfo = count;
            VmLogisticCargo model = new VmLogisticCargo();
            model.EncriptID = "0";
            model.ImageUrl = new List<string>() { "", "", "" };
            model.ImageID = new List<string>() { "", "", "" };
            return View(model);
        }

        /// <summary>
        /// 添加货源信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult AddCargoInfo(string EncriptID)
        {
            VmLogisticCargo model = new VmLogisticCargo();
            try{
            TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                var p = GetImageInfo();
                string flag = logisticCargoService.AddLogisticCargoInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 修改货源信息
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult EditCargoInfo(string EncryptID, string IsPerview = "")
        {
            var count = this.logisticCargoService.GetLogisticCargoInfoCount();
            ViewBag.CountInfo = count;
            ViewBag.IsPerview = IsPerview;
            var model = logisticCargoService.GetLogisticCargoInfoBy(EncryptID);
            if (model != null)
            {
                if (model.ImageID == null)
                {
                    model.ImageID = new List<string>();
                    model.ImageUrl = new List<string>();
                }
                for (int i = model.ImageID.Count; i < 3; i++)
                {
                    model.ImageID.Add("");
                    model.ImageUrl.Add("");
                }

                return View("AddCargoInfo", model);
            }
            return Content("未找到该信息!");
        }

        /// <summary>
        /// 修改货源信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult EditCargoInfo(bool IsPostBack = true)
        {
            VmLogisticCargo model = new VmLogisticCargo();
            try{
            TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                var p = GetImageInfo();
                string flag = logisticCargoService.UpdateLogisticCargoInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 列表页面
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult CargoIndex(string state = "3")
        {
            var count = this.logisticCargoService.GetLogisticCargoInfoCount();
            ViewBag.CountInfo = count;
            ViewBag.state = state;
            return View();
        }

        /// <summary>
        /// 得到货源列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetCargoPager(SmLogisticCargo search, int page, int rows)
        {
            var pager = logisticCargoService.GetLogisticCargoPager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 删除货源信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult DeleteCargo(string eid)
        {
            var vm = logisticCargoService.GetLogisticCargoInfoBy(eid);
            if (vm != null)
            {
                vm.Flag = 0;
                string flag = logisticCargoService.UpdateLogisticCargoInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("删除失败");
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 刷新货源信息
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult RefreshCargoInfo(string eid)
        {
            var vm = logisticCargoService.GetLogisticCargoInfoBy(eid);
            if (vm != null)
            {
                vm.RefreshDate = DateTime.Now;
                string flag = logisticCargoService.UpdateLogisticCargoInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("刷新失败");
                }
            }
            return Content("未提到该信息");
        }
        /// <summary>
        /// 提交货源信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult ApproveCargoInfo(string eid)
        {
            var vm = logisticCargoService.GetLogisticCargoInfoBy(eid);
            if (vm != null)
            {
                if ((!vm.Flag.HasValue) || vm.Flag != 1)
                {
                    return Content("该信息不能提交");
                }
                else
                {
                    vm.Flag = 2;
                    string flag = logisticCargoService.UpdateLogisticCargoInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("提交失败");
                    }
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 得到货源统计信息
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult GetCargoCount()
        {
            var count = this.logisticCargoService.GetLogisticCargoInfoCount();
            return Content(Utils.ToJsonStr(count));
        }

        /// <summary>
        /// 货源批量操作
        /// </summary>
        /// <param name="type"></param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult CargoBatch(int type, string chooses = "")
        {
            string flag = logisticCargoService.CargoBatch(type, chooses);
            return Content(flag);
        }
        #endregion

        #region 物流专线信息

        /// <summary>
        /// 添加物流专线信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult AddRouteInfo()
        {
            var enterprise = enterpriseService.GetCurrentEntInfo();
            if (enterprise == null || enterprise.EnterpriseID == 0)
            {
                return Content("<script type='text/javascript'>alert('请先完善企业信息');window.location.href='/My/EntInfo?mid=61'</script>");
            }
            else if (enterprise != null && enterprise.Flag.HasValue && enterprise.Flag == 0)
            {
                return Content("<script type='text/javascript'>alert('企业被冻结请联系管理员');history.back(-1);</script>");
            } var count = this.logisticRouteService.GetLogisticRouteInfoCount();
            ViewBag.CountInfo = count;
            SetVehicle();
            VmLogisticRoute model = new VmLogisticRoute();
            model.EncriptID = "0";
            model.ImageUrl = new List<string>() { "", "", "" };
            model.ImageID = new List<string>() { "", "", "" };
            return View(model);
        }

        /// <summary>
        /// 添加物流专线信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult AddRouteInfo(string EncriptID)
        {
            VmLogisticRoute model = new VmLogisticRoute();
            try
            {
                TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                var p = GetImageInfo();
                string flag = logisticRouteService.AddLogisticRouteInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 修改物流专线信息
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult EditRouteInfo(string EncryptID, string IsPerview = "")
        {
            var count = this.logisticRouteService.GetLogisticRouteInfoCount();
            ViewBag.CountInfo = count;
            SetVehicle();
            ViewBag.IsPerview = IsPerview;
            var model = logisticRouteService.GetLogisticRouteInfoBy(EncryptID);
            if (model != null)
            {
                if (model.ImageID == null)
                {
                    model.ImageID = new List<string>();
                    model.ImageUrl = new List<string>();
                }
                for (int i = model.ImageID.Count; i < 3; i++)
                {
                    model.ImageID.Add("");
                    model.ImageUrl.Add("");
                }

                return View("AddRouteInfo", model);
            }
            return Content("未找到该信息!");
        }

        /// <summary>
        /// 修改物流专线信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult EditRouteInfo(bool IsPostBack = true)
        {
            VmLogisticRoute model = new VmLogisticRoute();
            try
            {
                TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                var p = GetImageInfo();
                string flag = logisticRouteService.UpdateLogisticRouteInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 列表页面
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult RouteIndex(string state = "3")
        {
            var count = this.logisticRouteService.GetLogisticRouteInfoCount();
            ViewBag.CountInfo = count;
            ViewBag.state = state;
            return View();
        }

        /// <summary>
        /// 得到物流专线列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetRoutePager(SmLogisticRoute search, int page, int rows)
        {
            var pager = logisticRouteService.GetLogisticRoutePager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 删除物流专线信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult DeleteRoute(string eid)
        {
            var vm = logisticRouteService.GetLogisticRouteInfoBy(eid);
            if (vm != null)
            {
                vm.Flag = 0;
                string flag = logisticRouteService.UpdateLogisticRouteInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("删除失败");
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 刷新物流专线信息
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult RefreshRouteInfo(string eid)
        {
            var vm = logisticRouteService.GetLogisticRouteInfoBy(eid);
            if (vm != null)
            {
                vm.RefreshDate = DateTime.Now;
                string flag = logisticRouteService.UpdateLogisticRouteInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("刷新失败");
                }
            }
            return Content("未提到该信息");
        }
        /// <summary>
        /// 提交物流专线信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult ApproveRouteInfo(string eid)
        {
            var vm = logisticRouteService.GetLogisticRouteInfoBy(eid);
            if (vm != null)
            {
                if ((!vm.Flag.HasValue) || vm.Flag != 1)
                {
                    return Content("该信息不能提交");
                }
                else
                {
                    vm.Flag = 2;
                    string flag = logisticRouteService.UpdateLogisticRouteInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("提交失败");
                    }
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 得到物流专线统计信息
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult GetRouteCount()
        {
            var count = this.logisticRouteService.GetLogisticRouteInfoCount();
            return Content(Utils.ToJsonStr(count));
        }

        /// <summary>
        /// 物流专线批量操作
        /// </summary>
        /// <param name="type"></param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult RouteBatch(int type, string chooses="")
        {
            string flag = logisticRouteService.RouteBatch(type, chooses);
            return Content(flag);
        }

        #endregion


        #region 辅助方法

        /// <summary>
        /// 上传图片，生成缩略图
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public PartialViewResult UploadPicture()
        {
            var file = Request.Files["upalbum"];
            var fid = Request.Form["fid"];
            if (file.ContentLength > 0)
            {
                string imagePath = ConfigurationManager.AppSettings["InfoImagePath"] == null ? "upload/info/" : ConfigurationManager.AppSettings["InfoImagePath"];
                string path = AppDomain.CurrentDomain.BaseDirectory + imagePath;
                string guid = Guid.NewGuid().ToString().Replace("-", "");
                string extensionName = file.FileName.Substring(file.FileName.LastIndexOf("."));
                string newName = guid;
                string fileName = path + "New" + newName + extensionName;
                string smallFileName = guid + "_small.jpg";
                file.SaveAs(fileName);
                //生成缩略图
                ImageHelper.CreateImage(80, 80, fileName, path + smallFileName);
                //加水印
                ImageHelper.DrawWords("New" + newName + extensionName, "金谷高科", 0.8f, ImagePosition.Center, path, guid);
                VmUploadPicture p = new VmUploadPicture();
                p.SmallFileName = smallFileName;
                p.Path = "/" + imagePath;
                p.FileName = "/" + imagePath + newName + ".jpg";
                p.ID = fid == null ? "" : fid;
                p.OriginalName = file.FileName;
                return PartialView("UploadPictureClose", p);
            }
            return PartialView("UploadPictureClose");

        }

        /// <summary>
        /// 得到图片信息
        /// </summary>
        /// <returns></returns>
        private VmB2BInfoPicture GetImageInfo()
        {
            VmB2BInfoPicture picture = new VmB2BInfoPicture();
            picture.OriginalName = new List<string>();
            picture.PictureIDs = new List<string>();
            picture.PictureUrls = new List<string>();
            for (int i = 1; i <= 3; i++)
            {
                var ID = Request.Form["ImageID" + i.ToString()];
                var FileName = Request.Form["ImageURL" + i.ToString()];
                var OriginalName = Request.Form["OriginalName" + i.ToString()];
                picture.OriginalName.Add(OriginalName == "" ? "" : OriginalName);
                picture.PictureIDs.Add(ID == "" ? "" : ID);
                picture.PictureUrls.Add(FileName == "" ? "" : FileName);
            }
            return picture;
        }

        /// <summary>
        /// 从ModelState返回所有错误信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [NonAction]
        private JsonResult GetError(ModelStateDictionary model)
        {
            List<string> sb = new List<string>();
            //获取所有错误的Key
            List<string> Keys = model.Keys.ToList();
            //获取每一个key对应的ModelStateDictionary
            foreach (var key in Keys)
            {
                var errors = ModelState[key].Errors.ToList();
                //将错误描述添加到sb中
                foreach (var error in errors)
                {
                    sb.Add(error.ErrorMessage);
                }
            }
            return Json(sb);
        }

        /// <summary>
        /// 设置车辆类型,车辆添加修改使用
        /// </summary>
        private void SetVehicleType()
        {
            SmBaseDictionary sm = new SmBaseDictionary();
            sm.ParentID = 12;
            var list = baseDictionary.GetBaseDictionarys(sm);
            if (list != null)
            {
                List<SelectListItem> l = new List<SelectListItem>();
                foreach (var d in list)
                {
                    l.Add(new SelectListItem() { Text = d.ItemName, Value = d.ItemID.ToString() });
                }
                ViewBag.TypeList = l;
            }
            else
            {
                ViewBag.TypeList = null;
            }
        }

        /// <summary>
        /// 设置车辆，车源添加修改使用
        /// </summary>
        private void SetVehicle()
        {
            var list = logisticVehicleService.GetCurrentUserVehicle();
            if (list != null)
            {
                List<SelectListItem> l = new List<SelectListItem>();
                l.Add(new SelectListItem() { Text="请选择",Value=""});
                foreach (var d in list)
                {
                    l.Add(new SelectListItem() { Text = d.LicenseNum, Value = d.EncriptID });
                }
                ViewBag.VehicleList = l;
            }
            else
            {
                ViewBag.VehicleList = null;
            }
        }
        #endregion
    }
}