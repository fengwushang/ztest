﻿using Fao.BadWord;
using Fao.Common;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using FaoB2B.Filters;
using Fao.Service.B2B;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FaoB2B.Controllers
{
    /// <summary>
    /// created by：yzq 2013-02-19
    /// 评论控制器
    /// </summary>
    public class CommentController : Controller
    {
        #region 调用服务对象。命名规范：对象名称=“接口名称去掉I，并小写首字母”

        IEvaluateService evaluateService = new EvaluateService();


        #endregion

        #region 模板。调用action。命名规范：方法名称=“页面名称，首字母大写。”
        /// <summary>
        /// 返回评论列表json字符串
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult List(string id, string type)
        {

            var json = evaluateService.GetMessageEvaluates(Utils.ToInt(Security.Decrypt(id)), Utils.ToInt(type));

            return Content(Utils.ToJsonStr(json));
        }

        /// <summary>
        /// 添加一条评论，并返回添加成功与否
        /// </summary>
        /// <param name="id">被评论信息id</param>
        /// <param name="type">被评论信息类型</param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult Add(VmEvaluate comment, string id, string type)
        {
            BadWordsFilter4 bf4 = new BadWordsFilter4();

            using (StreamReader sw = new StreamReader(System.IO.File.OpenRead(Server.MapPath("~/Config/BadWord.txt"))))
            {
                Random random = new Random();
                string key = sw.ReadLine();
                while (key != null)
                {
                    if (key != string.Empty)
                    {

                        bf4.AddKey(key);
                    }
                    key = sw.ReadLine();
                }
            }

            //var has = bf4.HasBadWord(text);

            comment.Text = bf4.Replace(comment.Text);

            var json = evaluateService.AddMessageEvaluate(comment,
                Utils.ToInt(Security.Decrypt(id)),
                Utils.ToInt(type));
            return Content(AddCommentMsg(Utils.ToInt(json)));
        }


        /// <summary>
        /// 返回添加好友或添加关注的提示消息
        /// </summary>
        /// <param name="flag"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        private string AddCommentMsg(int flag)
        {
            string rv = string.Empty;

            switch (flag)
            {
                case 1:

                    rv = "评论成功！";

                    break;
                case 2:

                    rv = "请登录后，再评论！";

                    break;

                default:
                    rv = "操作失败！";
                    break;
            }

            return "{ \"msg\":\"" + rv + "\"}";
        }

        #endregion

    }
}
