﻿using Fao.Common;
using Fao.Data.B2B;
using Fao.Data.B2B.SM;
using Fao.Interface.B2B;
using FaoB2B.Filters;
using Fao.Service.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FaoB2B.Controllers
{
    /// <summary>
    /// created by：mbx 2013-02-20
    /// 日志控制器
    /// </summary>
    public class BaseLogController : Controller
    {
        #region 服务对象

        IBaseLogService baseLogService = new BaseLogService();

        #endregion


        /// <summary>
        /// 日志列表页面视图
        /// </summary>
        /// <returns></returns>
        public ActionResult List()
        {
            return View();
        }

        /// <summary>
        /// 根据SmBaseLog查询模型，返回VmBaseLog分页数据
        /// </summary>
        /// <param name="SmBaseLog">查询模型</param>
        /// <param name="pageIndex">页所引</param>
        /// <param name="pageCount">页记录数</param>
        /// <returns>分页数据</returns>
        [ActionLogException]
        [HttpPost]
        public ContentResult List(SmBaseLog log, int page, int rows)
        {
            var json = Utils.ToJsonStr(baseLogService.GetBaseLogs(log,page,rows));
            return Content(json);
        }

        /// <summary>
        /// 查看日志详情
        /// </summary>
        /// <param name="id">日志id</param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult Detail(string id)
        {
            var log = baseLogService.GetBaseLogByID(id);
            return View(log);
        }
    }
}
