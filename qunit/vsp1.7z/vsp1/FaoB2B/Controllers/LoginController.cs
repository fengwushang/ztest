﻿using Fao.Common;
using Fao.Data.B2B;
using Fao.Data.B2B.MV;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using FaoB2B.Filters;
using Fao.Service.B2B;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using System.Web.Mvc;

namespace FaoB2B.Controllers
{
    /// <summary>
    /// 登陆注册
    /// </summary>
    public class LoginController : Controller
    {
        #region 业务接口引用

        //将需要的服务接口引用，添加到这里
        IBaseUserService baseUserService = new BaseUserService();
        IBaseLogService baseLogService = new BaseLogService();
        #endregion


        #region 登陆

        /// <summary>
        /// 返回默认页面
        /// </summary>
        /// <returns></returns>
        public ActionResult Index(string returnUrl)
        {
            ViewBag.ReturnUrl = Security.Decrypt(returnUrl);
            return View();
        }

        /// <summary>
        /// 登陆验证
        /// </summary>
        /// <param name="UserName">用户名</param>
        /// <param name="Password">密码</param>
        /// <param name="ValidateCode">验证码</param>
        /// <param name="returnUrl">验证成功后转到页面</param>
        /// <returns></returns>
        [ActionLogException]
        [HttpPost]
        public ActionResult Index(VmLogin model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                if (!(GetCode().ToLower() == model.ValidateCode.ToLower()))
                {
                    ModelState.AddModelError("ValidateCode", "验证码错误！");
                    return View(model);
                }
                var error = new NameValueCollection();
                bool flag = baseUserService.ValidateUser(model.UserName, model.PassWord, ref error);
                if (flag)
                {
                    baseUserService.Login(model.UserName, model.PassWord, model.AutoLogin);
                    if (string.IsNullOrEmpty(returnUrl))
                    {
                        return RedirectToLocal("/Home");
                    }
                    else
                    {
                        return RedirectToLocal(returnUrl);
                    }
                    
                }
                else
                {
                    if (error["UserName"] != null)
                    {
                        ModelState.AddModelError("UserName", error["UserName"]);
                    }
                    if (error["Password"] != null)
                    {
                        ModelState.AddModelError("PassWord", error["PassWord"]);
                    }
                }
                ViewBag.ReturnUrl = returnUrl;
            }
            return View(model);
        }
        [ActionLogException]
        [OutputCache(Duration = 0)]
        public ActionResult Logout()
        {
            baseUserService.Logout();
            return Redirect("/home/index");
        }

        #endregion

        #region 注册

        /// <summary>
        /// 注册
        /// </summary>
        /// <returns></returns>
        public ActionResult Register()
        {
            return View();
        }

        /// <summary>
        /// 注册
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        [HttpPost]
        public ActionResult Register(VmRegister model)
        {
            if (ModelState.IsValid)
            {
                int flag = baseUserService.RegisterUser(model);
                if (flag > 1)
                {
                    //baseUserService.Login(model.Email, model.Password, false);
                    //注册成功后，跳转至 欢迎界面

                   // System.Threading.Thread.Sleep(3000);
                   //ViewBag.href= System.IO.File.ReadAllText(Server.MapPath("~/11.txt"));

                    return View("WelcomeNewUser");
                }

                if (flag == -1)
                {
                    ModelState.AddModelError("Email", "该邮箱已被注册，不能再使用！");
                    return View(model);
                }
                return View();
            }
            return View();
        }

        #endregion

        //邮箱验证 激活用户
        [ActionLogException]
        public ActionResult RegisterVer(string code, string uid)
        {  
            VmRegister vm = new VmRegister()
            {
                EmailVerifyCode = code,
                UserID = uid
            };
            ViewBag.flag = baseUserService.VerifyUserMail(vm);
            return View();
        }

        #region 忘记密码
        public ActionResult EmailValidate()
        {
            return View();
        }

        //发送验证码
        [ActionLogException]
        [HttpPost]
        public ActionResult EmailValidate(string Email)
        {
            if (Regex.IsMatch(Email, @"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$"))
            {
                int flag = baseUserService.CheckEmail(Email);
                if (flag >= 1)
                {
                    Fao.Common.SendMail.MailContent content = new SendMail.MailContent();
                    content.emailAdd = Email;
                    string validateCode = Fao.Common.ValidateCode.CreateRandNum(5);
                    Tuple<string, string> mailVal = new Tuple<string, string>(Email, validateCode);
                    Fao.Common.HtmlHelper.SetCookie("ValidateCode",validateCode, DateTime.Now.AddHours(1));
                    Fao.Common.HtmlHelper.SetCookie("ChangEmail", Email, DateTime.Now.AddHours(1));
                 
                    Thread tsEmail = new Thread(new ParameterizedThreadStart(SendVerMail));
                    tsEmail.Start(mailVal);

                    //return View("GetBackPassword");
                    return Redirect("/Login/GetBackPassword");
                }
                else
                {
                    ModelState.AddModelError("", "该EMail未注册");
                }
            }
            else
            {
                ModelState.AddModelError("", "请填写正确的EMail");
            }
            return View();
        }

        public ActionResult GetBackPassword()
        {

            return View();
        }
        /// <summary>
        /// 取回密码
        /// </summary>
        /// <param name="ValidateCode"></param>
        /// <param name="NewPassword"></param>
        /// <returns></returns>
        [ActionLogException]
        [HttpPost]
        public ActionResult GetBackPassword(VmGegBackPassword model)
        {
            if (Fao.Common.HtmlHelper.GetCookieValue("ValidateCode") == model.ValidationCode)
            {
                string email = Fao.Common.HtmlHelper.GetCookieValue("ChangEmail");
                int flag = baseUserService.ChangPassword(email, model.NewPassword, "");
                if (flag != 0)
                {
                    return RedirectToAction("Index", "Login");
                }
            }
            return View();
        }


        #endregion

        #region 修改密码
        public ActionResult ChangePassword()
        {
            return View();
        }
        [ActionLogException]
        [HttpPost]
        public ActionResult ChangePassword(VmChangPassword model)
        {
            if (ModelState.IsValid)
            {
                int flag = baseUserService.ChangPassword("", model.NewPassword, model.OldPassword);
                if (flag != 0)
                {
                    return RedirectToAction("My", "Home");
                }
                ModelState.AddModelError("", "修改失败请联系管理员！");
            }
            return View();
        }

        #endregion

        #region 验证码
        [OutputCache(Duration = 0)]
        [ActionLogException]
        public ActionResult VCode()
        {
            string code = ValidateCode.CreateRandomCode(4);

            var bytes = ValidateCode.CreateImage(code);
            string EncriptCode = Security.Encrypt(code);
            Fao.Common.HtmlHelper.SetCookie("vcode", EncriptCode, DateTime.Now.AddMinutes(10));

            return File(bytes, @"image/jpeg");
        }

        public string GetCode()
        {
            var EncriptCode = Fao.Common.HtmlHelper.GetCookieValue("vcode");
            string code=string.Empty;
            if (EncriptCode != string.Empty)
            {
                code = Security.Decrypt(EncriptCode);
            }
            return code;
        }
        #endregion

        #region 辅助方法
        /// <summary>
        /// 页面跳转
        /// </summary>
        /// <param name="returnUrl"></param>
        /// <returns></returns>
        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        /// <summary>
        /// 检查EMail
        /// </summary>
        /// <param name="Email"></param>
        /// <returns></returns>
        [ActionLogException]
        [OutputCache(Duration = 0)]
        public ContentResult CheckEmail(string Email)
        {
            int flag = baseUserService.CheckEmail(Email);
            return Content(flag.ToString());
        }

        /// <summary>
        /// 发送验证邮件。注册时做邮箱号码唯一性判断
        /// 验证后，激活该用户
        /// </summary>
        /// <param name="user"></param>
        [ActionLogException]
        private void SendVerMail(object validateCode)
        {

            Tuple<string, string> mailVal = validateCode as Tuple<string, string>;
            SendMail.MailContent mc = new SendMail.MailContent();
            mc.emailAdd = mailVal.Item1;
            mc.emailSub = "金谷高科找回密码--邮箱验证邮件";
            mc.EmailBody = string.Format(@"<font face=Arial size=2>亲爱的用户：<br/>&nbsp;&nbsp;&nbsp;&nbsp;您好！<br/>
                &nbsp;&nbsp;&nbsp;&nbsp;验证码是: {0} , 有效期10分钟 ", mailVal.Item2);

            SendMail.SEmail(mc);
        }

        #endregion
    }
}
