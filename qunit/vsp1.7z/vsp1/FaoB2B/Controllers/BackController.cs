﻿using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using Fao.Service.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fao.Common;
using FaoB2B.Filters;

namespace FaoB2B.Controllers
{
    /// <summary>
    /// created by：yzq 2013-02-19
    /// 电商后台控制器
    /// </summary>
    public class BackController : Controller
    {
        #region 引用的服务

        ISiteSetService siteSetService = new SiteSetService();
        IBaseDictionaryService baseDictionaryService = new BaseDictionaryService();

        IBaseLogService baseLogService = new BaseLogService();

        ICategoryService categoryService = new CategoryService();

        IB2BInfoService b2BInfoService = new B2BInfoService();

        IEnterpriseService enterpriseService = new EnterpriseService();

        IBaseAdminService baseAdminService = new BaseAdminService();

        IBaseAreaService baseAreaService = new BaseAreaService();

        IBaseIndustryService baseIndustryService = new BaseIndustryService();

        IUserTransactionService userTransactionService = new UserTransactionService();

        ILogisticVehicleService logisticVehicleService = new LogisticVehicleService();

        ILogisticVehicleSourceService logisticVehicleSourceService = new LogisticVehicleSourceService();

        ILogisticCargoService logisticCargoService = new LogisticCargoService();
        ILogisticStoreService logisticStoreService = new LogisticStoreService();
        ILogisticRouteService logisticRouteService = new LogisticRouteService();

        IHotWordService hotWordService = new HotWordService();

        IPPCService pPCService = new PPCService();

        IHotWordPriceService hotWordPriceService = new HotWordPriceService();

        ISMSBlackListService sMSBlackListService = new SMSBlackListService();

        #endregion
        //
        // GET: /Back/
        [ActionLogException]
        public ActionResult Index()
        {
            ViewBag.Index = "easyui-layout";
            return View();
        }

        #region 地区

        /// <summary>
        /// 返回分类默认页
        /// </summary>
        /// <returns></returns>
        public ActionResult Area()
        {
            return View();
        }

        /// <summary>
        /// 返回地区列表
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult AreaList(int id)
        {
            SmBaseArea sm = new SmBaseArea();
            sm.ParentID = id;
            List<VmBaseArea> list = baseAreaService.GetAreas(sm);
            return Content(Utils.ToJsonStr(list));
        }

        /// <summary>
        /// 删除地区
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult AreaDel(int id)
        {
            int flag = baseAreaService.DeleteArea(id);
            if (flag >= 0)
            {
                return Content("1");
            }
            else
            {
                return Content("-1");
            }
        }

        /// <summary>
        /// 添加地区
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [ActionLogException]
        [HttpPost]
        public ActionResult AreaAdd(VmBaseArea model)
        {

            string flag = baseAreaService.AddArea(model);
            if (flag == "1")
            {
                return Content("1");
            }
            return Content(flag);
        }

        /// <summary>
        /// 修改地区
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [HttpPost]
        [ActionLogException]
        public ActionResult AreaEdit(VmBaseArea model)
        {

            string flag = baseAreaService.UpdateArea(model);

            if (flag == "1")
            {
                return Content("1");
            }
            return Content(flag);
        }

        /// <summary>
        /// 地区上移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult AreaUp(int ItemID)
        {
            string res = baseAreaService.ItemUP(ItemID);
            if (res == "1")
            {
                return Content("1");
            }
            else if (res == "-1")
            {
                return Content("设置失败");
            }
            return Content(res);
        }

        /// <summary>
        /// 地区下移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult AreaDown(int ItemID)
        {
            string res = baseAreaService.ItemDown(ItemID);
            if (res == "1" || res == "0")
            {
                return Content("1");
            }
            else if (res == "-1")
            {
                return Content("设置失败");
            }
            return Content(res);
        }


        #endregion

        #region 行业

        /// <summary>
        /// 返回行业默认页
        /// </summary>
        /// <returns></returns>
        public ActionResult Ind()
        {
            return View();
        }

        /// <summary>
        /// 返回行业列表
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult IndList(int id)
        {
            SmBaseIndustry sm = new SmBaseIndustry();
            sm.ParentID = id;
            List<VmBaseIndustry> list = baseIndustryService.GetBaseIndustrys(sm);
            return Content(Utils.ToJsonStr(list));
        }

        /// <summary>
        /// 删除行业
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult IndDel(int id)
        {
            int flag = baseIndustryService.DeleteInd(id);
            if (flag >= 0)
            {
                return Content("1");
            }
            else
            {
                return Content("-1");
            }
        }

        /// <summary>
        /// 添加行业
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [ActionLogException]
        [HttpPost]
        public ActionResult IndAdd(VmBaseIndustry model)
        {

            string flag = baseIndustryService.AddInd(model);
            if (flag == "1")
            {
                return Content("1");
            }
            return Content(flag);
        }

        /// <summary>
        /// 修改行业
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [HttpPost]
        [ActionLogException]
        public ActionResult IndEdit(VmBaseIndustry model)
        {
            string flag = baseIndustryService.UpdateInd(model);
            if (flag == "1")
            {
                return Content("1");
            }
            return Content(flag);
        }

        /// <summary>
        /// 行业上移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult IndUp(int ItemID)
        {
            string res = baseIndustryService.ItemUP(ItemID);
            if (res == "1")
            {
                return Content("1");
            }
            else if (res == "-1")
            {
                return Content("设置失败");
            }
            return Content(res);
        }

        /// <summary>
        /// 行业下移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult IndDown(int ItemID)
        {
            string res = baseIndustryService.ItemDown(ItemID);
            if (res == "1" || res == "0")
            {
                return Content("1");
            }
            else if (res == "-1")
            {
                return Content("设置失败");
            }
            return Content(res);
        }


        #endregion

        #region 字典

        /// <summary>
        /// 返回字典默认页
        /// </summary>
        /// <returns></returns>
        public ActionResult Dictionary()
        {
            return View();
        }

        /// <summary>
        /// 把字典列表
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult DictionaryList(int ParentID)
        {
            SmBaseDictionary sm = new SmBaseDictionary();
            sm.ParentID = ParentID;
            List<VmBaseDictionary> list = baseDictionaryService.GetBaseDictionarys(sm);
            return Content(Utils.ToJsonStr(list));
        }

        /// <summary>
        /// 返回根据别名查询的，子集字典数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult Dicts(string abb)
        {
            SmBaseDictionary sm = new SmBaseDictionary();
            sm.AbbName = abb;
            List<VmBaseDictionary> list = baseDictionaryService.GetBaseDictionarys(sm);
            return Content(Utils.ToJsonStr(list));
        }

        /// <summary>
        /// 删除字典项
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult DeleteItem(int ItemID)
        {
            int flag = baseDictionaryService.DeleteDictionItem(ItemID);
            if (flag >= 0)
            {
                return Content("1");
            }
            else
            {
                return Content("-1");
            }
        }

        /// <summary>
        /// 添加字典项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [ActionLogException]
        [HttpPost]
        public ActionResult AddItem(VmBaseDictionary model)
        {
            if (ModelState.IsValid)
            {
                string flag = baseDictionaryService.AddDictionItem(model);
                if (flag == "1")
                {
                    return Content("1");
                }
                return Content(flag);
            }
            string error = ModelState.Aggregate("", (a, b) => a + (b.Value.Errors.Count > 0 ? b.Value.Errors.Aggregate("", (c, d) => c + d.ErrorMessage + "<br />") : ""));
            return Content(error);
        }

        /// <summary>
        /// 修改字典项
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [HttpPost]
        [ActionLogException]
        public ActionResult EditItem(VmBaseDictionary model)
        {

            if (ModelState.IsValid)
            {
                string flag = baseDictionaryService.UpdateDictionItem(model);
                if (flag == "1")
                {
                    return Content("1");
                }
                return Content(flag);
            }
            string error = ModelState.Aggregate("", (a, b) => a + (b.Value.Errors.Count > 0 ? b.Value.Errors.Aggregate("", (c, d) => c + d.ErrorMessage + "<br />") : ""));
            return Content(error);
        }

        /// <summary>
        /// 字典项上移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult ItemUp(int ItemID)
        {
            string res = baseDictionaryService.ItemUP(ItemID);
            if (res == "1")
            {
                return Content("1");
            }
            else if (res == "-1")
            {
                return Content("设置失败");
            }
            return Content(res);
        }

        /// <summary>
        /// 字典项下移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult ItemDown(int ItemID)
        {
            string res = baseDictionaryService.ItemDown(ItemID);
            if (res == "1" || res == "0")
            {
                return Content("1");
            }
            else if (res == "-1")
            {
                return Content("设置失败");
            }
            return Content(res);
        }
        #endregion

        #region 分类

        /// <summary>
        /// 返回分类默认页
        /// </summary>
        /// <returns></returns>
        public ActionResult Category()
        {
            return View();
        }

        /// <summary>
        /// 把分类列表
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult CategoryList(int ParentID)
        {
            SmCategory sm = new SmCategory();
            sm.ParentID = ParentID;
            List<VmCategory> list = categoryService.GetCategorys(sm);
            return Content(Utils.ToJsonStr(list));
        }

        /// <summary>
        /// 删除分类项
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult DeleteCategory(int ItemID)
        {
            int flag = categoryService.DeleteCategory(ItemID);
            if (flag >= 0)
            {
                return Content("1");
            }
            else
            {
                return Content("-1");
            }
        }

        /// <summary>
        /// 添加分类项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [ActionLogException]
        [HttpPost]
        public ActionResult AddCategory(VmCategory model)
        {
            if (ModelState.IsValid)
            {
                string flag = categoryService.AddCategory(model);
                if (flag == "1")
                {
                    return Content("1");
                }
                return Content(flag);
            }
            string error = ModelState.Aggregate("", (a, b) => a + (b.Value.Errors.Count > 0 ? b.Value.Errors.Aggregate("", (c, d) => c + d.ErrorMessage + "<br />") : ""));
            return Content(error);
        }

        /// <summary>
        /// 修改分类项
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [HttpPost]
        [ActionLogException]
        public ActionResult EditCategory(VmCategory model)
        {

            if (ModelState.IsValid)
            {
                string flag = categoryService.Updatecategory(model);
                if (flag == "1")
                {
                    return Content("1");
                }
                return Content(flag);
            }
            string error = ModelState.Aggregate("", (a, b) => a + (b.Value.Errors.Count > 0 ? b.Value.Errors.Aggregate("", (c, d) => c + d.ErrorMessage + "<br />") : ""));
            return Content(error);
        }

        /// <summary>
        /// 分类项上移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult CategoryUp(int ItemID)
        {
            string res = categoryService.ItemUP(ItemID);
            if (res == "1")
            {
                return Content("1");
            }
            else if (res == "-1")
            {
                return Content("设置失败");
            }
            return Content(res);
        }

        /// <summary>
        /// 分类项下移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult CategoryDown(int ItemID)
        {
            string res = categoryService.ItemDown(ItemID);
            if (res == "1" || res == "0")
            {
                return Content("1");
            }
            else if (res == "-1")
            {
                return Content("设置失败");
            }
            return Content(res);
        }


        #endregion

        #region B2B审批

        /// <summary>
        /// 审批默认页面
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult B2BInfoAuditing()
        {
            var state = baseDictionaryService.GetBaseDictionarys(new SmBaseDictionary() { ParentID = 12 });
            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem() { Text = "全部", Value = "0" });
            foreach (var i in state)
            {
                list.Add(new SelectListItem() { Text = i.ItemName, Value = i.ItemID.ToString() });
            }
            ViewBag.Type = list;
            return View();
        }

        /// <summary>
        /// 分页列表 
        /// </summary>
        /// <param name="sm"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult B2BInfoAuditingList(SmB2BInfo sm, int page, int rows)
        {
            var pager = b2BInfoService.GetAuditingPager(sm, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 返回细节
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult B2BInfoDetail(string EncriptID)
        {
            string strID = Security.Decrypt(EncriptID);
            int id = 0;
            if (int.TryParse(strID, out id))
            {
                var model = b2BInfoService.GetB2BInfoByID(id);
                return View(model);
            }
            else
            {
                return Content("未找到该信息");
            }
        }

        /// <summary>
        /// 审批信息
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult Auditing(string ID, int Result)
        {
            if (Result == -1)
            {
                var agree = Request.Form["Agree"];
                var disagree = Request.Form["Disagree"];
                Result = agree != null ? 3 : 4;
            }
            string flag = b2BInfoService.AuditingB2BInfo(ID, Result);
            return Content(flag);
        }
        #endregion

        #region 日志
        /// <summary>
        /// 返回日志默认页
        /// </summary>
        /// <returns></returns>
        public ActionResult Log()
        {
            return View();
        }

        /// <summary>
        /// 根据SmBaseLog查询模型，返回日志分页数据
        /// </summary>
        /// <param name="SmBaseLog">查询模型</param>
        /// <param name="pageIndex">页所引</param>
        /// <param name="pageCount">页记录数</param>
        /// <returns>分页数据</returns>
        [ActionLogException]
        [HttpPost]
        public ContentResult LogList(SmBaseLog log, int page, int rows)
        {
            var json = Utils.ToJsonStr(baseLogService.GetBaseLogs(log, page, rows));
            return Content(json);
        }

        /// <summary>
        /// 查看日志详情
        /// </summary>
        /// <param name="id">日志id</param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult LogDetail(string id)
        {
            var log = baseLogService.GetBaseLogByID(id);
            return View(log);
        }
        #endregion

        #region 物流审批

        #region 车辆审批

        public ActionResult VehicleAuditing()
        {
            return View();
        }

        /// <summary>
        /// 分页列表 
        /// </summary>
        /// <param name="sm"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult VehicleList(SmLogisticVehicle sm, int page, int rows)
        {
            var pager = logisticVehicleService.GetAuditingPager(sm, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 返回细节
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult VehicleDetail(string EncriptID)
        {
            string strID = Security.Decrypt(EncriptID);
            int id = 0;
            if (int.TryParse(strID, out id))
            {
                var model = logisticVehicleService.GetLogisticVehicleByID(EncriptID);
                return View(model);
            }
            else
            {
                return Content("未找到该信息");
            }
        }

        /// <summary>
        /// 审批信息
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult AuditingVehicle(string ID, int Result)
        {
            if (Result == -1)
            {
                var agree = Request.Form["Agree"];
                var disagree = Request.Form["Disagree"];
                Result = agree != null ? 3 : 4;
            }
            string flag = logisticVehicleService.Auditing(ID, Result);
            return Content(flag);
        }

        #endregion

        #region 车源审批

        public ActionResult VehicleSourceAuditing()
        {
            return View();
        }

        /// <summary>
        /// 分页列表 
        /// </summary>
        /// <param name="sm"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult VehicleSourceList(SmLogisticVehicleSource sm, int page, int rows)
        {
            var pager = logisticVehicleSourceService.GetAuditingPager(sm, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 返回细节
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult VehicleSourceDetail(string EncriptID)
        {
            string strID = Security.Decrypt(EncriptID);
            int id = 0;
            if (int.TryParse(strID, out id))
            {
                var model = logisticVehicleSourceService.GetVehicleSourceInfoBy(EncriptID);
                return View(model);
            }
            else
            {
                return Content("未找到该信息");
            }
        }

        /// <summary>
        /// 审批信息
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult AuditingVehicleSource(string ID, int Result)
        {
            if (Result == -1)
            {
                var agree = Request.Form["Agree"];
                var disagree = Request.Form["Disagree"];
                Result = agree != null ? 3 : 4;
            }
            string flag = logisticVehicleSourceService.Auditing(ID, Result);
            return Content(flag);
        }

        #endregion

        #region 货源审批

        public ActionResult CargoAuditing()
        {
            return View();
        }

        /// <summary>
        /// 分页列表 
        /// </summary>
        /// <param name="sm"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult CargoList(SmLogisticCargo sm, int page, int rows)
        {
            var pager = logisticCargoService.GetAuditingPager(sm, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 返回细节
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult CargoDetail(string EncriptID)
        {
            string strID = Security.Decrypt(EncriptID);
            int id = 0;
            if (int.TryParse(strID, out id))
            {
                var model = logisticCargoService.GetLogisticCargoInfoBy(EncriptID);
                return View(model);
            }
            else
            {
                return Content("未找到该信息");
            }
        }

        /// <summary>
        /// 审批信息
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult AuditingCargo(string ID, int Result)
        {
            if (Result == -1)
            {
                var agree = Request.Form["Agree"];
                var disagree = Request.Form["Disagree"];
                Result = agree != null ? 3 : 4;
            }
            string flag = logisticCargoService.Auditing(ID, Result);
            return Content(flag);
        }


        #endregion

        #region 库源审批

        public ActionResult StoreAuditing()
        {
            return View();
        }

        /// <summary>
        /// 分页列表 
        /// </summary>
        /// <param name="sm"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult StoreList(SmLogisticStore sm, int page, int rows)
        {
            var pager = logisticStoreService.GetAuditingPager(sm, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 返回细节
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult StoreDetail(string EncriptID)
        {
            string strID = Security.Decrypt(EncriptID);
            int id = 0;
            if (int.TryParse(strID, out id))
            {
                var model = logisticStoreService.GetLogisticStoreInfoBy(EncriptID);
                return View(model);
            }
            else
            {
                return Content("未找到该信息");
            }
        }

        /// <summary>
        /// 审批信息
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult AuditingStore(string ID, int Result)
        {
            if (Result == -1)
            {
                var agree = Request.Form["Agree"];
                var disagree = Request.Form["Disagree"];
                Result = agree != null ? 3 : 4;
            }
            string flag = logisticStoreService.Auditing(ID, Result);
            return Content(flag);
        }


        #endregion

        #region 物流专线审批

        public ActionResult RouteAuditing()
        {
            return View();
        }

        /// <summary>
        /// 分页列表 
        /// </summary>
        /// <param name="sm"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult RouteList(SmLogisticRoute sm, int page, int rows)
        {
            var pager = logisticRouteService.GetAuditingPager(sm, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 返回细节
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult RouteDetail(string EncriptID)
        {
            string strID = Security.Decrypt(EncriptID);
            int id = 0;
            if (int.TryParse(strID, out id))
            {
                var model = logisticRouteService.GetLogisticRouteInfoBy(EncriptID);
                return View(model);
            }
            else
            {
                return Content("未找到该信息");
            }
        }

        /// <summary>
        /// 审批信息
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult AuditingRoute(string ID, int Result)
        {
            if (Result == -1)
            {
                var agree = Request.Form["Agree"];
                var disagree = Request.Form["Disagree"];
                Result = agree != null ? 3 : 4;
            }
            string flag = logisticRouteService.Auditing(ID, Result);
            return Content(flag);
        }


        #endregion

        #endregion

        #region 企业用户管理

        /// <summary>
        /// 企业页面视图
        /// </summary>
        /// <returns></returns>
        public ActionResult Ent()
        {
            return View();
        }

        /// <summary>
        /// 企业列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult EntList(SmEnterprise user, int page, int rows)
        {
            var json = enterpriseService.GetAdminEnterprises(user, page, rows);
            return Content(Utils.ToJsonStr(json));
        }

        /// <summary>
        /// 企业详细信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult EntDetail(string id)
        {
            var json = enterpriseService.GetEnterpriseByID(id);
            return Content(json.Detail);
        }

        //账户充值
        [ActionLogException]
        public ContentResult ReCharge(FormCollection fc)
        {
            int money = Utils.ToInt(fc["money"]);
            int uid = Utils.ToInt(Security.Decrypt(fc["uid"]));
            return Content(userTransactionService.ReCharge(uid, money));
        }

        //冻结账户
        [ActionLogException]
        public ContentResult Freeze(string eid)
        {
            int id = Utils.ToInt(Security.Decrypt(eid));
            return Content(enterpriseService.FreezeEnt(id));
        }

        #endregion

        #region 系统管理员管理

        /// <summary>
        /// 管理员页面视图
        /// </summary>
        /// <returns></returns>
        public ActionResult Admin()
        {
            return View();
        }


        /// 管理员列表数据分页数据
        /// </summary>
        /// <param name="SmBaseAdmin">查询模型</param>
        /// <param name="pageIndex">页所引</param>
        /// <param name="pageCount">页记录数</param>
        /// <returns>分页数据</returns>
        [ActionLogException]
        [HttpPost]
        public ContentResult AdminList(SmBaseAdmin user, int page, int rows)
        {
            var json = baseAdminService.GetBaseAdmins(user, page, rows);
            return Content(Utils.ToJsonStr(json));
        }

        /// <summary>
        /// 删除管理员
        /// </summary>
        /// <param name="ItemID">管理员id</param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult DeleteAdmin(int id)
        {
            int flag = baseAdminService.RemoveAdminByID(id);
            if (flag >= 0)
            {
                return Content("1");
            }
            else
            {
                return Content("-1");
            }
        }


        /// <summary>
        /// 添加管理员
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [ActionLogException]
        [HttpPost]
        public ActionResult AddAdmin(VmBaseAdmin model)
        {
            if (ModelState.IsValid)
            {
                int flag = baseAdminService.AddAdmin(model);
                return Content(flag.ToString());
            }
            string error = ModelState.Aggregate("", (a, b) => a + (b.Value.Errors.Count > 0 ? b.Value.Errors.Aggregate("", (c, d) => c + d.ErrorMessage + "<br />") : ""));
            return Content(error);
        }

        /// <summary>
        /// 修改管理员
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [ActionLogException]
        public ActionResult EditAdmin(VmBaseAdmin model)
        {
            if (ModelState.IsValid)
            {
                int flag = baseAdminService.UpdateAdmin(model);
                return Content(flag.ToString());
            }
            string error = ModelState.Aggregate("", (a, b) => a + (b.Value.Errors.Count > 0 ? b.Value.Errors.Aggregate("", (c, d) => c + d.ErrorMessage + "<br />") : ""));
            return Content(error);
        }

        /// <summary>
        /// 管理员登陆
        /// </summary>
        /// <returns></returns>
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ActionLogException]
        public ContentResult Login(VmBaseAdmin model, string returnUrl)
        {
            if (!(GetCode() == model.ValidateCode.ToLower()))
            {
                return Content("2");
            }

            var admin = baseAdminService.ValidateUser(model.VarAdminName, model.VarPassWord);
            if (admin != null)
            {
                Fao.Common.HtmlHelper.SetCookie("AdminName", HttpUtility.UrlEncode( admin.VarRealName));
                Fao.Common.HtmlHelper.SetCookie("AdminID", admin.IntAdminID.ToString());

                return Content("1");
            }
            else
            {

                return Content("-1");
            }

        }
        [ActionLogException]
        public ContentResult Logout()
        {
            Fao.Common.HtmlHelper.ClearCookie("AdminName");
            Fao.Common.HtmlHelper.ClearCookie("AdminID");
            return Content("1");
        }

        [ActionLogException]
        public string GetCode()
        {
            var EncriptCode = Fao.Common.HtmlHelper.GetCookieValue("vcode");
            string code = string.Empty;
            if (EncriptCode != string.Empty)
            {
                code = Security.Decrypt(EncriptCode).ToLower();
            }
            return code.ToLower();
        }

        #endregion

        #region 系错误页
        public ViewResult ErrorView(string msg)
        {
            ViewBag.ErrorMes = msg;
            return View();
        }
        #endregion

        #region 热词管理

        /// <summary>
        /// 热词列表
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult HotWord()
        {
            return View();
        }

        /// <summary>
        /// 热词列表数据
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult HotWordList(SmHotWord sm, int page, int rows)
        {
            var pager=hotWordService.GetHotWordPaging(sm, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 用户出价列表
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult PPC()
        {
            return View();
        }

        /// <summary>
        /// 用户出价列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult PPCList(SmPPC sm,int page,int rows)
        {
            var pager = pPCService.GetPPCPaging(sm, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 热词价格列表 
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult HotWordPrice()
        {
            return View();
        }

        /// <summary>
        /// 热词价格列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult HotWordPriceList(SmHotWordPrice sm,int page,int rows)
        {
            var pager = hotWordPriceService.GetHotWordPricePaging(sm, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 添加热词价格
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult AddHotWordPrice(VmHotWordPrice model)
        {
            if (model.IntWordType == 0)
            {
                return Content("请选择热词类型");
            }
            if (ModelState.IsValid)
            {
                string flag = hotWordPriceService.AddHotWordPrice(model);
                if (flag == "1")
                {
                    return Content("1");
                }
                return Content(flag);
            }
            string error = ModelState.Aggregate("", (a, b) => a + (b.Value.Errors.Count > 0 ? b.Value.Errors.Aggregate("", (c, d) => c + d.ErrorMessage + "<br />") : ""));
            return Content(error);

        }

        /// <summary>
        /// 删除热词价格
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult DeleteHotWordPrice(string EncriptID)
        {
            string flag = hotWordPriceService.DeleteHotWordPrice(EncriptID);
            return Content(flag);
        }

        /// <summary>
        /// 修改热词价格
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        [HttpPost]
        [ActionLogException]
        public ActionResult EditHotWordPrice(VmHotWordPrice model)
        {
            if (model.IntWordType == 0)
            {
                return Content("请选择热词类型");
            }
            if (ModelState.IsValid)
            {
                string flag = hotWordPriceService.UpdateHotWordPrice(model);
                if (flag == "1")
                {
                    return Content("1");
                }
                return Content(flag);
            }
            string error = ModelState.Aggregate("", (a, b) => a + (b.Value.Errors.Count > 0 ? b.Value.Errors.Aggregate("", (c, d) => c + d.ErrorMessage + "<br />") : ""));
            return Content(error);
        }
        #endregion

        #region 黑名单
        /// <summary>
        /// 手机黑名单 列表页视图
        /// </summary>
        /// <returns></returns>
        public ActionResult SMSIndex()
        {
            return View();
        }


        /// <summary>
        /// 手机黑名单 获取列表
        /// </summary> 
        /// <returns></returns>
        [HttpPost]
        public ContentResult SMSList(SmSMSBlackList dl, string page, string rows)
        {
            VmSMSBlackListList pager = sMSBlackListService.GetSMSBlackListList(dl, page, rows,"0");
            return Content(Utils.ToJsonStr(pager));
        }


        /// <summary>
        /// 手机黑名单 添加视图
        /// </summary>
        /// <returns></returns>
        public ActionResult SMSAdd()
        {
            return View("SMSEdit");
        }


        /// <summary>
        /// 手机黑名单 编辑视图
        /// </summary>
        /// <returns></returns>
        public ActionResult SMSEdit(string id)
        {
            var modle = sMSBlackListService.GetSMSBlackListByID(id);
            return View(modle);
        }

        /// <summary>
        /// 手机黑名单 编辑操作
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ContentResult SMSEdit(VmSMSBlackList dl)
        {
            dl.IntUserID = "0";
            return Content(sMSBlackListService.Save(dl,"0"));
        }



        /// <summary>
        /// 手机黑名单 删除操作
        /// </summary>
        /// <returns></returns>
        public ContentResult SMSDelete(string id)
        {
            return Content(sMSBlackListService.RemoveToEntitys(new VmSMSBlackList
            {
                IntSMSBlackListID = Utils.ToInt(id).ToString()
            }));
        }

        /// <summary>
        /// 手机黑名单 浏览视图
        /// </summary>
        /// <returns></returns>
        public ActionResult SMSDetail(string id)
        {
            var modle = sMSBlackListService.GetSMSBlackListByID(id);
            return View(modle);
        }
       
        #endregion

        #region 站点生成

        /// <summary>
        /// 首页
        /// </summary>
        /// <returns></returns>
        public ActionResult SiteSet()
        {
            return View();
        }

        /// <summary>
        /// 生成首页
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ContentResult SetIndex()
        {
            string result = siteSetService.SetIndex();
            return Content(Utils.ToJsonStr(result));
        }

        #endregion

    }

}
