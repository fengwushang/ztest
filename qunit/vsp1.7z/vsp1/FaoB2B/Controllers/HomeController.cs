﻿using Fao.BadWord;
using Fao.Common;
using Fao.Data.B2B.MV;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using Fao.Service.B2B;
using FaoB2B.Filters;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace FaoB2B.Controllers
{
    /// <summary>
    /// created by：yzq 2013-02-19
    /// 电商站点信息控制器 
    /// </summary>
    public class HomeController : Controller
    {
        #region 调用服务对象。命名规范：对象名称=“接口名称去掉I，并小写首字母”

        IUserFriendService userFriendService = new UserFriendService();

        IBaseUserService baseUserService = new BaseUserService();

        ILogisticRouteService logisticRouteService = new LogisticRouteService();
        ILogisticVehicleSourceService logisticVehicleSourceService = new LogisticVehicleSourceService();
        ILogisticStoreService logisticStoreService = new LogisticStoreService();
        ILogisticCargoService logisticCargoService = new LogisticCargoService();
        IB2BInfoService infoService = new B2BInfoService();
        IHotWordService hotwordService = new HotWordService();

        #endregion

        #region 模板。调用action。命名规范：方法名称=“页面名称，首字母大写。”
        [ActionLogException]
        public ActionResult Index()
        {

            return Redirect("/index.htm");
        }
        [ActionLogException]
        public ActionResult About()
        {

            ViewBag.Message = "你的应用程序说明页。";

            ViewBag.TopicID = Security.Encrypt("26");
            ViewBag.TopicType = 1;

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "你的联系方式页。";


            return View();
        }

        /// <summary>
        /// 绘制主页面公共头部分部视图数据。
        /// </summary>
        /// <returns></returns>
        [ChildActionOnly]
        [ActionLogException]
        public ActionResult Head()
        {
            
            HotWordString model = hotwordService.GetHotWordString();
            return PartialView("_PartialHead", model);

        }

        [HttpPost]
        public ActionResult Head(VmSimpLogin model)
        {
            var error = new NameValueCollection();
            bool flag = baseUserService.ValidateUser(model.UserName, model.PassWord, ref error);
            if (flag)
            {
                baseUserService.Login(model.UserName, model.PassWord, true);
                var result = new { Flag=1,Data=HttpUtility.UrlDecode(Fao.Common.HtmlHelper.GetCookieValue("B2B_UserName"))};
                return Content(Utils.ToJsonStr(result));
            }
            else
            {
                return Content(Utils.ToJsonStr(new{Flag=0,Data=error["UserName"]}));
            }
        }

        //检索五类消息时，将热词写入数据库
        [ActionLogException]
        public ActionResult Infoshw(string id, string type)
        {
            if (string.IsNullOrEmpty(type))
            {
                ViewBag.Key = string.Empty;
            }
            else
            {
                ViewBag.Key = HttpUtility.UrlDecode(type);
            }
            if (string.IsNullOrEmpty(id))
            {
                ViewBag.Type = "1";
            }
            else
            {
                ViewBag.Type = id;
            }

            if (!string.IsNullOrEmpty(type) && !string.IsNullOrEmpty(id))
            {
                string temString = Regex.Replace(HttpUtility.UrlDecode(type).Trim(), @"\s+", " ");
                string[] zu = temString.Split(' ');
                foreach (string str in zu)
                {
                    if (str.Length > 1)
                    {
                        hotwordService.AddHotWord(id, str);
                    }
                }
            }
            if (string.IsNullOrEmpty(type))
                return Redirect("/home/Infos/" + id);
            else
                return Redirect("/home/Infos/" + id + "/" + HttpUtility.UrlDecode(type));
        }

        [ActionLogException]
        public ActionResult Infos(string id, string type)
        {
            if (string.IsNullOrEmpty(type))
            {
                ViewBag.Key = string.Empty;
            }
            else
            {
                ViewBag.Key = HttpUtility.UrlDecode(type);
            }
            if (string.IsNullOrEmpty(id))
            {
                ViewBag.Type = "1";
            }
            else
            {
                ViewBag.Type = id;
            }

            return View();
        }


        #region 加好友、加关注

        /// <summary>
        /// 加为好友
        /// </summary>
        /// <param name="id"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult AddFriend(string id)
        {
            var success = userFriendService.AddFriend(Utils.ToInt(Security.Decrypt(id)), 2);

            return Content(AddFriendMsg(Utils.ToInt(success), 2));
        }

        /// <summary>
        /// 加关注
        /// </summary>
        /// <param name="id"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult AddAttention(string id)
        {
            var success = userFriendService.AddFriend(Utils.ToInt(Security.Decrypt(id)), 1);

            return Content(AddFriendMsg(Utils.ToInt(success), 1));
        }

        /// <summary>
        /// 返回添加好友或添加关注的提示消息
        /// </summary>
        /// <param name="flag"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        [ActionLogException]
        private string AddFriendMsg(int flag, int type)
        {
            string rv = string.Empty;

            switch (flag)
            {
                case 1:
                    if (type == 1)
                    {
                        rv = "添加关注成功！";
                    }
                    else
                    {

                        rv = "添加好友成功！";
                    }
                    break;
                case 2:
                    if (type == 1)
                    {
                        rv = "请登录后，添加关注！";
                    }
                    else
                    {

                        rv = "请登录后，添加好友！";
                    }
                    break;
                case 3:
                    if (type == 1)
                    {
                        rv = "您已经关注了该用户！";
                    }
                    else
                    {

                        rv = "该用户已经是您的好友！";
                    }
                    break;
                case 4:
                    if (type == 1)
                    {
                        rv = "不需要关注自己！";
                    }
                    else
                    {

                        rv = "不需要添加自己做为好友！";
                    }
                    break;
                default:
                    rv = "操作失败！";
                    break;
            }

            return "{ \"msg\":\"" + rv + "\"}";
        }

        #endregion

        /// <summary>
        /// 文件上传测试
        /// </summary>
        /// <returns>返回消息</returns>
        [ActionLogException]
        public JsonResult Upload()
        {
            HttpPostedFileBase file = Request.Files[0];
            var fileName = Path.Combine(Request.MapPath("~/Upload"), Path.GetFileName(file.FileName));
            string msg = "";
            try
            {
                file.SaveAs(fileName);
                msg = string.Format("{0} 上传成功!", Path.GetFileName(file.FileName));
            }
            catch
            {
                msg = string.Format("{0} 上传失败!", Path.GetFileName(file.FileName));
            }
            return Json(msg);
        }

        #endregion
    }
}
