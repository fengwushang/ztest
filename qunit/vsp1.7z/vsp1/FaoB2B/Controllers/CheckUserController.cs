﻿using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using Fao.Service.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fao.Common;
using FaoB2B.Filters;

namespace FaoB2B.Controllers
{
    public class CheckUserController : Controller
    {
        //
        // GET: /CheckUser/
        #region   引用服务
        IBasePlatUserService basePlatUserService = new BasePlatUserService();
        #endregion

        /// <summary>
        ///显示页面 
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        { 
            return View();
        }

        /// <summary>
        /// 初始化View,取得 其他平台URL
        /// </summary>
        /// <returns></returns>
        public ActionResult b2bGoPs()
        {
            ViewBag.HR = Utils.GetAppValueByName("URL_HR");
            ViewBag.PS = Utils.GetAppValueByName("URL_PS");
            return View();
        }

        /// <summary>
        ///   向联合登录表中加入一条数据 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public ContentResult b2bEdit(string IntTypeID)
        {
            PlatUser model = new PlatUser();
            model.IntTypeID = IntTypeID;
            return Content(basePlatUserService.AddEntity(model));
        }

        //检测用户是否存在
        [ActionLogException]
        [HttpPost]
        public string Edit(string userID, string IntTypeID, string VarTokenID)
        {
            //IntTypeID = Security.Decrypt(IntTypeID);
            userID = Security.Decrypt(userID);
            VarTokenID = Security.Decrypt(VarTokenID);
            int result = basePlatUserService.GetCheckToken(Utils.ToInt(IntTypeID), Utils.ToInt(userID), VarTokenID);
            if (result > 0)
            {
                //baseUserService.Login(model.UserName, model.PassWord, model.AutoLogin);
                basePlatUserService.Login_ps(userID);
                return "1";
            }
            else
            {
                return "0";
            }
        }

        /// <summary>
        /// 页面跳转
        /// </summary>
        /// <param name="returnUrl"></param>
        /// <returns></returns>
        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
    }
}
