﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fao.Data.B2B;
using Fao.Data.B2B.SM;
using Fao.Interface.B2B;
using Fao.Service.B2B;
using Fao.Common;
using FaoB2B.Filters;

namespace FaoB2B.Controllers
{
    /// <summary>
    /// created by：yzq 2013-02-18
    /// 供求招合代 四类信息控制器，
    /// supply and demand，canvass，cooperation，agency
    /// </summary>
    public class SdccaController : Controller
    {

        #region 调用服务对象。命名规范：对象名称=“接口名称去掉I，并小写首字母”

        //ITemplateService templateService = new TemplateService();
        IB2BInfoService infoService = new B2BInfoService();

        #endregion

        #region 视图定位
        /// <summary>
        /// 定位供求招合代的主页面视图
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            return View();
        }

        
        /// <summary>
        /// 定位供求招合代的比对页面视图
        /// </summary>
        /// <param name="id">接受“1,2,3,4,5”最多五个信息加密ID参数</param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult Compare(string id,string type)
        {
            ViewBag.Type = type;
            var infoList = infoService.GetCompareInfos(id);
            return View(infoList);
        }

        #endregion

        #region 模板。调用action。命名规范：方法名称=“页面名称，首字母大写。”



        /// <summary>
        /// 搜索供求招代合，信息
        /// </summary>
        /// <param name="info"></param>
        /// <param name="id"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult Search(SmB2BInfo info, int page, int rows)
        {

            var json = infoService.SearchInfosPaging(info, page, rows);

            return Content(Utils.ToJsonStr(json));
        }

        #endregion

    }
}