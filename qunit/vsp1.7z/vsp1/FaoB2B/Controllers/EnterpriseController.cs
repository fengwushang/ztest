﻿using Fao.Common;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using FaoB2B.Filters;
using Fao.Service.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FaoB2B.Controllers
{
    /// <summary>
    /// created by：mbx 2013-02-28
    /// 电商信息（供求招代合）控制器
    /// </summary>
    public class EnterpriseController : Controller
    {
         #region 引用的服务

        IEnterpriseService enterpriseService=new EnterpriseService();

        #endregion


        /// <summary>
        /// 根据企业id 获取企业信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult GetEnterprise(string id)
        {
            var ent = enterpriseService.GetEnterpriseByID(id);
            return Content(Utils.ToJsonStr(ent));
        }
    }
}
