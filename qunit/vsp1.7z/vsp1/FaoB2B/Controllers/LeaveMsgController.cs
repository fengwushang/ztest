﻿using Fao.Common;
using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using FaoB2B.Filters;
using Fao.Service.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FaoB2B.Controllers
{
    /// <summary>
    /// created by：mbx 2013-02-22
    /// 留言（询价、报价）控制器
    public class LeaveMsgController : Controller
    {
        #region 引用的服务

        IProductService productService = new ProductService();
        ILeaveMsgService leaveMsgService = new LeaveMsgService();
        IBaseUserService baseUserService = new BaseUserService();
        #endregion

        /// <summary>
        /// created by：mbx 2013-02-22
        /// 留言（询价、报价）控制器
        /// </summary>
        public ActionResult Index()
        {
            return View();
        }


        /// <summary>
        /// 询价页面视图
        /// </summary>
        /// <param name="tableId">来源表</param>
        /// <param name="ids">询价产品id 集合串</param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult Inquiry(string tableId, string ids,string t)
        {
            VmLeaveMsg vmLeaveMsg = new VmLeaveMsg();
            var list = new List<VMMsgObject>();
            if (!string.IsNullOrEmpty(ids))
            {
                //获取询价产品
                list = leaveMsgService.GetMsgObjects(tableId, ids);
            }
            ViewBag.Products = list;
            ViewBag.Type = t;
            //var user = baseUserService.CurrentUser();
            //if (user == null)
            //{
            //    user = new BaseUser();
            //    user.VarRealName = string.Empty;
            //    user.VarPhone = string.Empty;
            //}
            var userInfo = baseUserService.GetCurrentUserInfo();
            if (userInfo == null)
            {
                userInfo = new VMUserInfo();
                userInfo.RealName = string.Empty;
                userInfo.Phone = string.Empty;
                userInfo.QQ = string.Empty;
                userInfo.Email = string.Empty;
                userInfo.Sex = 1;
            }
            //vmLeaveMsg.IntSex = Utils.ToInt(userInfo.Sex.ToString());
            //vmLeaveMsg.VarPhone = userInfo.Phone;
            //vmLeaveMsg.VarTelPhone = string.Empty;
            //vmLeaveMsg.VarQQ = userInfo.QQ;
            //vmLeaveMsg.VarEmail = userInfo.Email;
            ViewBag.User = userInfo;


            ViewBag.TableID = tableId;
            return View();
        }


        /// <summary>
        /// 添加询价
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [ActionLogException]
        [ValidateInput(false)]
        public ContentResult AddLeaveMsg(VmLeaveMsg model)
        {
            if (ModelState.IsValid)
            {
                string msg = "";
                if (model.VarCode.ToLower() != GetCode())
                {
                    msg = "{ \"msg\":\"验证码错误\"}";
                }
                else
                {
                    int flag = leaveMsgService.AddLeaveMsgByIds(model);
                    if (flag > 0)
                    {
                        msg = "{ \"msg\":\"提交成功\"}";
                    }
                    else
                    {
                        msg = "{ \"msg\":\"提交失败\"}";
                    }
                }
                return Content(msg);
            }
            string error = ModelState.Aggregate("", (a, b) => a + (b.Value.Errors.Count > 0 ? b.Value.Errors.Aggregate("", (c, d) => c + d.ErrorMessage + "<br />") : ""));
            return Content(error);
        }

        /// <summary>
        /// 获取当前联系人
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public string GetContact()
        {
            VMUserInfo user = baseUserService.GetCurrentUserInfo();
            return Utils.ToJsonStr(user);
        }

        //获取Cookie验证码，Cookie过期返回一个随机码
        [ActionLogException]
        public string GetCode()
        {
            var EncriptCode = Fao.Common.HtmlHelper.GetCookieValue("vcode");
            string code=string.Empty;
            if (EncriptCode != string.Empty)
            {
                code = Security.Decrypt(EncriptCode).ToLower();
            }
            return code;
        }


        /// <summary>
        /// 报价页面视图
        /// </summary>
        /// <param name="tableId">来源表</param>
        /// <param name="ids">报价产品id 集合串</param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult Quote(string tableId, string ids,string t)
        {
            var list = new List<VMMsgObject>();
            if (!string.IsNullOrEmpty(ids))
            {
                //获取报价产品
                list = leaveMsgService.GetMsgObjects(tableId, ids);
            }

            ViewBag.Products = list;

            //var user = baseUserService.CurrentUser();
            //if (user == null)
            //{
            //    user = new BaseUser();
            //    user.VarRealName = string.Empty;
            //    user.VarPhone = string.Empty;
            //}
            var userInfo = baseUserService.GetCurrentUserInfo();
            if (userInfo == null)
            {
                userInfo = new VMUserInfo();
                userInfo.RealName = string.Empty;
                userInfo.Phone = string.Empty;
                userInfo.QQ = string.Empty;
                userInfo.Email = string.Empty;
                userInfo.Sex = 1;
            }
            ViewBag.User = userInfo;
            ViewBag.TableID = tableId;
            ViewBag.Type = t;
            return View();
        }

        /// <summary>
        /// 留言页面视图
        /// </summary>
        /// <param name="tableId">来源表</param>
        /// <param name="ids">留言产品id 集合串</param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult Msg(string tableId, string ids,string t)
        {
            ViewBag.Type = t;
            string name = string.Empty;
            switch (t)
            {
                case "3": name = "招商"; break;
                case "4": name = "合作"; break;
                case "5": name = "代理"; break;
            }
            ViewBag.Name = name;
            var list = new List<VMMsgObject>();
            if (!string.IsNullOrEmpty(ids))
            {
                //获取报价产品
                list = leaveMsgService.GetMsgObjects(tableId, ids);
            }

            //var user = baseUserService.CurrentUser();
            //if (user == null)
            //{
            //    user = new BaseUser();
            //    user.VarRealName = string.Empty;
            //    user.VarPhone = string.Empty;
            //}
            var userInfo = baseUserService.GetCurrentUserInfo();
            if (userInfo == null)
            {
                userInfo = new VMUserInfo();
                userInfo.RealName = string.Empty;
                userInfo.Phone = string.Empty;
                userInfo.QQ = string.Empty;
                userInfo.Email = string.Empty;
                userInfo.Sex = 1;
            }
            ViewBag.User = userInfo;
            ViewBag.Products = list;
            ViewBag.TableID = tableId;
            ViewBag.Type = t;
            return View();
        }

    }
}
