﻿using Fao.Common;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Data.Sms;
using Fao.Interface.B2B;
using Fao.Service.B2B;
using FaoB2B.Filters;
using System.Threading;
using System.Web.Mvc; 

namespace FaoB2B.Controllers
{
    
    public class SmsController : Controller
    {
        
        #region 调用服务对象。命名规范：对象名称=“接口名称去掉I，并小写首字母”

        IBaseUserService baseUserService = new BaseUserService();
        IUserTransactionService userTransactionService = new UserTransactionService();
        ISMSBuyLogService smsBuyLogService = new SMSBuyLogService();
        ISms_MT_BatchService smsMTBatchServive = new Sms_MT_BatchService();
        ISms_MT_DetailService smsMTDetailService = new Sms_MT_DetailService();
        ISMSBlackListService sMSBlackListService = new SMSBlackListService();
        #endregion


        #region 验证手机，或修改并验证
        /// <summary>
        /// created by：chf 2013-3-11 14:39:40
        /// 短信控制器 
        /// </summary>
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 获取当前登录用户的手机号
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        [OutputCache(Duration = 0)]
        public ActionResult PhoneVerify(string id)
        {
            var userInfo = baseUserService.CurrentUser();
            ViewData["UserPhoneNum"] = userInfo.VarPhone;

            if (id != null && id.Equals("1")) //修改手机号
            {
                return View();
            }

            //手机是否已经验证：1已验证，2没验证
            if (userInfo.IntPhoneVerify == 1) //已经验证过 
            {
                var userTransaction = userTransactionService.GetCurrentUserTransaction();
                if (userTransaction.PhoneMsgSum > 0)
                {
                    return Redirect("/SMS/Outbox?mid=34");//跳转到发短信页面
                }
                else
                {
                    return Redirect("/SMS/BuySms?mid=34"); //购买短信
                }
            }
            //else
            //{
            //    if (userInfo.IntPhoneVerify == 0)//用户没有填写手机号，此处填写并验证
            //    {

            //    }
            //    else
            //        if (userInfo.IntPhoneVerify == 2)//已经填写了手机号，并没有通过验证
            //        {

            //        } 
            //}
            return View();
        }

        /// <summary>
        /// 给用户填写的手机号发送短信
        /// </summary>
        /// <param name="PhoneNum"></param>
        /// <returns></returns> 
        [ActionLogException]
        [OutputCache(Duration = 0)]
        public ContentResult PhoneVerifyNum(string PhoneNum)
        {
            var userInfo = baseUserService.CurrentUser(); 
            string validCode = ValidateCode.CreateRandNum(4);

            SendSms.SmsSend SS = new SendSms.SmsSend();
            SS.smsContetnt = "您在金谷高科注册的手机验证码是[ " + validCode + " ]，请立即进行验证。时间：" + System.DateTime.Now.ToString();
            SS.smsSendUserID = 1; //公共短信，由 UserID=1 的保留用户来发送
            SS.smsReceiveNumList = userInfo.IntUserID + "A" + PhoneNum;

            Fao.Common.HtmlHelper.SetCookie("ValidCodePhone", validCode, System.DateTime.Now.AddHours(1));
            Fao.Common.HtmlHelper.SetCookie("PhoneNum", PhoneNum, System.DateTime.Now.AddHours(1));
             

            Thread tsPhone = new Thread(new ParameterizedThreadStart(SendVerMsg));
            tsPhone.Start(SS);

            return Content("1");
        }


        /// <summary>
        /// 发送验证短信。注册时做手机号码唯一性判断
        /// </summary>
        /// <param name="user"></param>
        private void SendVerMsg(object SPMsg)
        {
            SendSms.SmsSend SS = SPMsg as SendSms.SmsSend;
            Fao.Data.Sms.SendSms.Insert(SS);
        }

        /// <summary>
        /// 验证用户手机接收到的验证码
        /// </summary>
        /// <param name="verifyCode"></param>
        /// <returns></returns>
        [OutputCache(Duration = 0)]
        public ContentResult PhoneVerifyCode(string verifyCode)
        {
            string validCode = Fao.Common.HtmlHelper.GetCookieValue("ValidCodePhone");
            string phoneNum = Fao.Common.HtmlHelper.GetCookieValue("PhoneNum");

            string re;
            if (verifyCode.Trim().Length == 0)
            {
                re = "请输入手机收到的验证码！";
            }
            else
                if (validCode.Length == 0 || phoneNum.Length == 0)
                {
                    re = "验证码超时，请重新发送！";
                }
                else
                    if (validCode.Equals(verifyCode.Trim()))
                    {
                        re = "1";

                        //修改用户手机号码，和验证状态
                        VMUserInfo model = new VMUserInfo();
                        model.Phone = phoneNum;
                        model.IntPhoneVerify = 1;
                        TryUpdateModel(model);
                        string flag = baseUserService.UpdateUserPhone(model);
                        if (!flag.Equals("1"))
                            re = flag;
                    }
                    else
                        re = "验证码不正确，请检查收到的验证码！";
            return Content(re.ToString());
        }

        #endregion

        #region 购买短信
        /// <summary>
        /// 购买短信控制器
        /// </summary>
        /// <returns></returns> 
        [ActionLogException]
        [OutputCache(Duration = 0)]
        public ActionResult BuySms()
        {
            var e = userTransactionService.GetCurrentUserTransaction();
            if (e != null)
            {
                ViewData["AccountBalance"] = e.AccountBalance;
                ViewData["PhoneSmsSum"] = e.PhoneMsgSum;
                ViewData["UnitPrice"] = SMSBuyLogService.SMSUnitPrice;
            }
            return View();
        }

        /// <summary>
        /// 购买短信
        /// </summary>
        /// <param name="BuySum"></param>
        /// <param name="PayPwd"></param>
        /// <returns></returns>
        [ActionLogException]
        [OutputCache(Duration = 0)]
        public ContentResult BuyPhoneSms(string BuySum, string PayPwd)
        {
            string info = smsBuyLogService.BuyPhoneSms(BuySum, PayPwd);
            return Content(info);
        }
        #endregion

        #region 后台发送短信
        /// <summary>
        /// 发送短信 控制器
        /// </summary>
        /// <returns></returns> 
        [ActionLogException]
        [OutputCache(Duration = 0)]
        public ActionResult SendSms()
        {
            var user = userTransactionService.GetCurrentUserTransaction();
            if (user != null)
                ViewData["balanceMsgCount"] = user.PhoneMsgSum;
            return View();
        }

        /// <summary>
        /// 发送短信
        /// </summary>
        /// <param name="MsgContent">短信内容</param>
        /// <param name="NumList">接收用户的UserID+"A"接收用户的手机号码(该号码必须经过验证)</param>
        /// 如 NumList：1365A13691433299,1366A15899998888
        /// <returns></returns>
        [ActionLogException]
        [OutputCache(Duration = 0)]
        public ContentResult SendSmsData(string MsgContent, string NumList)
        {
            string info = smsMTDetailService.SendSms(MsgContent, NumList);
            return Content(info);
        }

        #endregion

        #region 前台发短信
        /// <summary>
        /// 前台发短信控制器
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult SendMsg(string nl,string t)
        {
            var e = baseUserService.CurrentUser();
            if (e == null)
                return Redirect("/login/index");

            ViewBag.reNumList = nl;
            var user = userTransactionService.GetCurrentUserTransaction();
            if (user != null)
            {
                ViewData["balanceMsgCount"] = user.PhoneMsgSum;
            }

            ViewBag.Type = t;
            return View();
        }

        /// <summary>
        /// 前台发短信，与后台区别 解密收信手机号字符串
        /// </summary>
        /// <param name="MsgContent"></param>
        /// <param name="NumList"></param>
        /// <returns></returns>
        [ActionLogException]
        [OutputCache(Duration = 0)]
        public ContentResult SendMsgData(string MsgContent, string NumList)
        {
            string info = smsMTDetailService.SendSms(MsgContent, Security.Decrypt(NumList));
            return Content(info);
        }
        #endregion

        #region 发件箱
        /// <summary>
        /// 发件箱 控制器
        /// </summary>
        /// <returns></returns>
        public ActionResult Outbox()
        {
            return View();
        }

        /// <summary>
        /// 得到发送列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetOutLogPager(SmSms_MT_Batch search, int page, int rows)
        {
            var pager = smsMTBatchServive.GetSmSmsBatchPager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 删除选择信息
        /// </summary>
        /// <param name="chooses"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult DeleteSMSChoose(string chooses)
        {
            if (chooses == null)
            {
                return Content("2");
            }
            var flag = smsMTBatchServive.DeleteSMSChoose(chooses);
            return Content("1");
        }


        /// <summary>
        /// 得到短信详细列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        [OutputCache(Duration = 0)]
        public ActionResult GetSMSDetailPager(SmSms_MT_Detail search, int page, int rows)
        {
            var pager = smsMTDetailService.GetSmSDetailPager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }
        #endregion

        #region 收件箱
        //收件箱控制器
        [ActionLogException]
        public ActionResult Inbox()
        {
            return View();
        }

        /// <summary>
        /// 得到收件箱 列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        [OutputCache(Duration = 0)]
        public ActionResult GetSmsInboxPager(smSmsInbox search, int page, int rows)
        {
            var pager = smsMTDetailService.GetSmsInboxPager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }
        #endregion

        #region 购买记录
        //购买记录
        [ActionLogException]
        public ActionResult BuyLog()
        {
            return View();
        }
        
        /// <summary>
        /// 得到 购买 列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        [OutputCache(Duration = 0)]
        public ActionResult GetBuyLogPager(SmSMSBuyLog search, int page, int rows)
        {
            var pager = smsBuyLogService.GetSmSMSBuyLogPager(search,   page,   rows);
            return Content(Utils.ToJsonStr(pager));
        }

        #endregion

        #region 黑名单
        /// <summary>
        /// 手机黑名单 列表页视图
        /// </summary>
        /// <returns></returns>
        public ActionResult SMSBlackIndex()
        {
            return View();
        }


        /// <summary>
        /// 手机黑名单 获取列表
        /// </summary> 
        /// <returns></returns>
        [HttpPost]
        public ActionResult SMSBlackList(SmSMSBlackList dl, string page, string rows)
        {
            var pager = sMSBlackListService.GetSMSBlackListList(dl, page, rows,"1");
            return Content(Utils.ToJsonStr(pager));
        }


        /// <summary>
        /// 手机黑名单 添加视图
        /// </summary>
        /// <returns></returns>
        public ActionResult SMSBlackAdd()
        {
            return View("SMSBlackEdit");
        }


        /// <summary>
        /// 手机黑名单 编辑视图
        /// </summary>
        /// <returns></returns>
        public ActionResult SMSBlackEdit(string id)
        {
            var modle = sMSBlackListService.GetSMSBlackListByID(id);
            return View(modle);
        }

        /// <summary>
        /// 手机黑名单 编辑操作
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ContentResult SMSBlackEdit(VmSMSBlackList dl)
        {
            dl.IntUserID = "0";
            return Content(sMSBlackListService.Save(dl,"1"));
        }



        /// <summary>
        /// 手机黑名单 删除操作
        /// </summary>
        /// <returns></returns>
        public ContentResult SMSBlackDelete(string id)
        {
            return Content(sMSBlackListService.RemoveToEntitys(new VmSMSBlackList
            {
                IntSMSBlackListID = Utils.ToInt(id).ToString()
            }));
        }

        /// <summary>
        /// 手机黑名单 浏览视图
        /// </summary>
        /// <returns></returns>
        public ActionResult SMSBlackDetail(string id)
        {
            var modle = sMSBlackListService.GetSMSBlackListByID(id);
            return View(modle);
        }
        #endregion
    }
}