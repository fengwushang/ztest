﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fao.Data.B2B;
using Fao.Interface.B2B;
using Fao.Service.B2B;
using Fao.Data.B2B.SM;
using Fao.Common;
using FaoB2B.Filters;
using Fao.Data.B2B.VM;
using System.Configuration;

namespace FaoB2B.Controllers
{
    /// <summary>
    /// created by：yzq 2013-02-20
    /// 个人端控制器
    /// </summary>
    public class MyController : Controller
    {
        #region 调用服务对象。命名规范：对象名称=“接口名称去掉I，并小写首字母”

        //IEvaluateService evaluateService = new EvaluateService();
        IUserFriendService userFriendService = new UserFriendService();
        IBaseUserService baseUserService = new BaseUserService();
        ILeaveMsgService leaveMsgService = new LeaveMsgService();
        IB2BInfoService b2bInfoService = new B2BInfoService();
        IEnterpriseService enterpriseService = new EnterpriseService();
        IUserTransactionService userTransactionService = new UserTransactionService();
        IPPCService ppcService = new PPCService();

        #endregion

        #region 模板。调用action。命名规范：方法名称=“页面名称，首字母大写。”

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Sdcca()
        {
            return View();
        }

        public ActionResult Logistic()
        {
            return View();
        }

        public ActionResult Info()
        {
            return View();
        }

        /// <summary>
        /// 绘制公共头部分部视图数据。
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        [ChildActionOnly]
        public ActionResult Head()
        {
            var user = baseUserService.GetBaseUserByID(string.Empty);

            return PartialView("_PartialMyHead", user);

        }

        #region 好友与关注

        /// <summary>
        /// 好友与关注 
        /// </summary>
        /// <returns></returns>
        public ActionResult Friend(int id = 1)
        {
            ViewBag.Type = id;
            return View();
        }

        /// <summary>
        /// 返回好友与关注列表
        /// </summary>
        /// <param name="sm"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult FriendList(SmUserFriend sm, int page, int rows)
        {
            var vm = userFriendService.GetUserFriendsWithPage(sm, page, rows);
            return Content(Utils.ToJsonStr(vm));
        }

        /// <summary>
        /// 删除好友
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult Delete(string eid)
        {
            string strId = Security.Decrypt(eid);
            int id = 0;
            int.TryParse(strId, out id);
            if (id == 0)
            {
                return Content("删除失败");
            }
            string flag = userFriendService.DeleteFriend(id);
            return Content(flag);
        }
        #endregion


        #region 留言
        /// <summary>
        /// 默认页面
        /// </summary>
        /// <returns></returns>
        public ActionResult LeaveMsg()
        {
            var PhoneVerify = baseUserService.GetCurrentUserInfo().IntPhoneVerify;
            ViewBag.PhoneVerify = PhoneVerify;
            return View();
        }

        /// <summary>
        /// 返回留言列表
        /// </summary>
        /// <param name="sm"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult LeaveMsgList(SmLeaveMsg sm, int page, int rows)
        {
            var vm = leaveMsgService.GetLeaveMsgsWithPager(sm, page, rows);
            return Content(Utils.ToJsonStr(vm));
        }
        /// <summary>
        /// 返回该条记录
        /// </summary>
        /// <param name="msgid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetLeaveMsg(string id)
        {
            string strId = Security.Decrypt(id);
            var entity = leaveMsgService.GetLeaveMsgByID(strId);
            return  Json(new { 
                title = entity.VarTitle
                , sex=entity.IntSex
                ,qq=entity.VarQQ
                ,email=entity.VarEmail
                ,phone=entity.VarPhone
                ,telphone=entity.VarTelPhone
                ,  content = entity.VarContent
                ,name = entity.VarContact
            }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 获取新信件数量
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult GetMsgCount()
        {
            string count = "0";
            try
            {
                var user = baseUserService.GetBaseUserByID(string.Empty);
                count = user.MsgCount.ToString();
            }
            catch (Exception ex)
            {
            }
            return Content(count);
        }

        /// <summary>
        /// 删除留言
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult DeleteLeaveMsg(string eid)
        {
            string strId = Security.Decrypt(eid);
            int id = 0;
            int.TryParse(strId, out id);
            if (id == 0)
            {
                return Content("删除失败");
            }
            string flag = leaveMsgService.DeleteLeaveMsg(id);
            return Content(flag);
        }

        /// <summary>
        /// 批量删除
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult DeleteLeaveMsgAll(string ids)
        {
            string flag = leaveMsgService.DeleteLeaveMsgAll(ids);
            return Content(flag);
        }

        #endregion

        #region 供应信息

        /// <summary>
        /// 添加供应信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult AddSupplyInfo()
        {
            var enterprise = enterpriseService.GetCurrentEntInfo();
            if (enterprise == null || enterprise.EnterpriseID == 0)
            {
                return Content("<script type='text/javascript'>alert('请先完善企业信息');window.location.href='/My/EntInfo?mid=61'</script>");
            }
            else if (enterprise != null && enterprise.Flag.HasValue && enterprise.Flag == 0)
            {
                return Content("<script type='text/javascript'>alert('企业被冻结请联系管理员');history.back(-1);</script>");
            }
            var count = b2bInfoService.GetB2BInfoCount(1);
            ViewBag.CountInfo = count;
            VmSupply model = new VmSupply();
            model.EncriptID = "0";
            model.ImageUrl = new List<string>() { "", "", "" };
            model.ImageID = new List<string>() { "", "", "" };
            return View(model);
        }

        /// <summary>
        /// 添加供应信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult AddSupplyInfo(string EncriptID)
        {
            VmSupply model = new VmSupply();
            try
            {
                TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                if (model.Total < model.MOQ)
                {
                    return Content("最小起订数不能大于供货总量");
                }
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                var p = GetImageInfo();
                string flag = b2bInfoService.AddSupplyInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 修改供应信息
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult EditSupplyInfo(string EncryptID, string IsPerview = "")
        {
            var count = b2bInfoService.GetB2BInfoCount(1);
            ViewBag.CountInfo = count;
            ViewBag.IsPerview = IsPerview;
            string decryptID = Fao.Common.Security.Decrypt(EncryptID);
            int id;
            if (int.TryParse(decryptID, out id))
            {
                VmSupply model = b2bInfoService.GetSupplyInfoBy(id);
                if (model.ImageID == null)
                {
                    model.ImageID = new List<string>();
                    model.ImageUrl = new List<string>();
                }
                for (int i = model.ImageID.Count; i < 3; i++)
                {
                    model.ImageID.Add("");
                    model.ImageUrl.Add("");
                }

                return View("AddSupplyInfo", model);
            }
            return Content("未找到该信息!");
        }

        /// <summary>
        /// 修改供应信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult EditSupplyInfo(bool IsPostBack = true)
        {

            VmSupply model = new VmSupply();
            try
            {
                TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                if (model.Total < model.MOQ)
                {
                    return Content("最小起订数不能大于供货总量");
                }
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                var p = GetImageInfo();
                string flag = b2bInfoService.UpdateSupplyInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 列表页面
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult SupplyIndex(string state = "3")
        {
            var count = b2bInfoService.GetB2BInfoCount(1);
            ViewBag.CountInfo = count;
            ViewBag.state = state;
            return View();
        }

        /// <summary>
        /// 得到供货列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetSupplyPager(SmSupply search, int page, int rows)
        {
            //VMSupplyPaging pager = new VMSupplyPaging();
            //pager.rows = new List<VmSupply>() { new VmSupply() };
            //pager.total = 1;

            var pager = b2bInfoService.GetSupplyPager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 删除供货信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult DeleteSupply(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetSupplyInfoBy(id);
                vm.Flag = 0;
                string flag = b2bInfoService.UpdateSupplyInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("删除失败");
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 预览供货信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult PreviewSupplyInfo(string EncryptID)
        {
            string DecryptID = Security.Decrypt(EncryptID);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetSupplyInfoBy(id);
                if (vm == null)
                {
                    return Content("未找到该信息");
                }
                return View(vm);
            }
            return Content("未找到该信息");
        }

        /// <summary>
        /// 提交供应信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult ApproveSupplyInfo(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetSupplyInfoBy(id);

                if ((!vm.Flag.HasValue) || vm.Flag != 1)
                {
                    return Content("该信息不能提交");
                }
                else
                {
                    vm.Flag = 2;
                    string flag = b2bInfoService.UpdateSupplyInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("提交失败");
                    }
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 提交求购信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult ApproveSupply(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetSupplyInfoBy(id);

                if ((!vm.Flag.HasValue) || vm.Flag != 1)
                {
                    return Content("该信息不能提交");
                }
                else
                {
                    vm.Flag = 2;
                    string flag = b2bInfoService.UpdateSupplyInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("提交失败");
                    }
                }
            }
            return Content("未找到该信息");
        }

        /// <summary>
        /// 刷新信息
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult RefreshSupplyInfo(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetSupplyInfoBy(id);

                if ((!vm.Flag.HasValue) || vm.Flag != 3)
                {
                    return Content("该信息不能刷新");
                }
                else
                {
                    vm.RefreshDate = DateTime.Now;
                    string flag = b2bInfoService.UpdateSupplyInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("刷新失败");
                    }
                }
            }
            return Content("未提到该信息");
        }

        #endregion

        #region 求购信息

        /// <summary>
        /// 添加求购信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult AddBuyInfo()
        {
            var enterprise = enterpriseService.GetCurrentEntInfo();
            if (enterprise == null || enterprise.EnterpriseID == 0)
            {
                return Content("<script type='text/javascript'>alert('请先完善企业信息');window.location.href='/My/EntInfo?mid=61'</script>");
            }
            else if (enterprise != null && enterprise.Flag.HasValue && enterprise.Flag == 0)
            {
                return Content("<script type='text/javascript'>alert('企业被冻结请联系管理员');history.back(-1);</script>");
            }
            var count = b2bInfoService.GetB2BInfoCount(2);
            ViewBag.CountInfo = count;
            VmBuy model = new VmBuy();
            model.EncriptID = "0";
            model.ImageUrl = new List<string>() { "", "", "" };
            model.ImageID = new List<string>() { "", "", "" };
            return View(model);
        }

        /// <summary>
        /// 添加求购信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult AddBuyInfo(string EncriptID)
        {
            VmBuy model = new VmBuy();
            try
            {
                TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                VmB2BInfoPicture p = GetImageInfo();
                string flag = b2bInfoService.AddBuyInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 修改求购信息
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult EditBuyInfo(string EncryptID, string IsPerview = "")
        {
            var count = b2bInfoService.GetB2BInfoCount(2);
            ViewBag.CountInfo = count;
            ViewBag.IsPerview = IsPerview;
            string decryptID = Fao.Common.Security.Decrypt(EncryptID);
            int id;
            if (int.TryParse(decryptID, out id))
            {
                VmBuy model = b2bInfoService.GetBuyInfoBy(id);
                if (model.ImageID == null)
                {
                    model.ImageID = new List<string>();
                    model.ImageUrl = new List<string>();
                }

                for (int i = model.ImageID.Count; i < 3; i++)
                {
                    model.ImageID.Add("");
                    model.ImageUrl.Add("");
                }
                return View("AddBuyInfo", model);
            }
            return Content("未找到该信息!");
        }

        /// <summary>
        /// 修改求购信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult EditBuyInfo(bool IsPostBack = true, string IsPerview = "")
        {
            ViewBag.IsPerview = IsPerview;
            VmBuy model = new VmBuy();
            try
            {
                TryUpdateModel(model);
            }
            catch
            { } 
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                VmB2BInfoPicture p = GetImageInfo();
                string flag = b2bInfoService.UpdateBuyInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 列表页面
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult BuyIndex(string state = "3")
        {
            var count = b2bInfoService.GetB2BInfoCount(2);
            ViewBag.CountInfo = count;
            ViewBag.state = state;
            return View();
        }

        /// <summary>
        /// 得到求购列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetBuyPager(SmBuy search, int page, int rows)
        {
            var pager = b2bInfoService.GetBuyPager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 删除求购信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult DeleteBuy(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetBuyInfoBy(id);

                vm.Flag = 0;
                string flag = b2bInfoService.UpdateBuyInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("删除失败");
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 预览求购信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult PreviewBuyInfo(string EncryptID)
        {
            string DecryptID = Security.Decrypt(EncryptID);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetBuyInfoBy(id);
                if (vm == null)
                {
                    return Content("未找到该信息");
                }
                return View(vm);
            }
            return Content("未找到该信息");
        }

        /// <summary>
        /// 提交求购信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult ApproveBuy(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetBuyInfoBy(id);

                if ((!vm.Flag.HasValue) || vm.Flag != 1)
                {
                    return Content("该信息不能提交");
                }
                else
                {
                    vm.Flag = 2;
                    string flag = b2bInfoService.UpdateBuyInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("提交失败");
                    }
                }
            }
            return Content("未找到该信息");
        }

        /// <summary>
        /// 刷新信息
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult RefreshBuyInfo(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetBuyInfoBy(id);

                if ((!vm.Flag.HasValue) || vm.Flag != 3)
                {
                    return Content("该信息不能刷新");
                }
                else
                {
                    vm.RefreshDate = DateTime.Now;
                    string flag = b2bInfoService.UpdateBuyInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("刷新失败");
                    }
                }
            }
            return Content("未提到该信息");
        }




        #endregion

        #region 合作信息

        /// <summary>
        /// 添加合作信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult AddCooperationInfo()
        {
            var enterprise = enterpriseService.GetCurrentEntInfo();
            if (enterprise == null || enterprise.EnterpriseID == 0)
            {
                return Content("<script type='text/javascript'>alert('请先完善企业信息');window.location.href='/My/EntInfo?mid=61'</script>");
            }
            else if (enterprise != null && enterprise.Flag.HasValue && enterprise.Flag == 0)
            {
                return Content("<script type='text/javascript'>alert('企业被冻结请联系管理员');history.back(-1);</script>");
            }
            var count = b2bInfoService.GetB2BInfoCount(4);
            ViewBag.CountInfo = count;
            VmCooperationInfo model = new VmCooperationInfo();
            model.EncriptID = "0";
            model.ImageUrl = new List<string>() { "", "", "" };
            model.ImageID = new List<string>() { "", "", "" };
            return View(model);
        }

        /// <summary>
        /// 添加合作信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult AddCooperationInfo(string EncriptID)
        {
            VmCooperationInfo model = new VmCooperationInfo();
            try
            {
            TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                VmB2BInfoPicture p = GetImageInfo();
                string flag = b2bInfoService.AddCooperationInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 修改合作信息
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult EditCooperationInfo(string EncryptID, string IsPerview = "")
        {
            var count = b2bInfoService.GetB2BInfoCount(4);
            ViewBag.CountInfo = count;
            ViewBag.IsPerview = IsPerview;
            string decryptID = Fao.Common.Security.Decrypt(EncryptID);
            int id;
            if (int.TryParse(decryptID, out id))
            {
                VmCooperationInfo model = b2bInfoService.GetCooperationInfoBy(id);
                if (model.ImageID == null)
                {
                    model.ImageID = new List<string>();
                    model.ImageUrl = new List<string>();
                }

                for (int i = model.ImageID.Count; i < 3; i++)
                {
                    model.ImageID.Add("");
                    model.ImageUrl.Add("");
                }
                //if (model.Flag == 2)
                //{
                //    return Content("该信息不能修改");
                //}
                return View("AddCooperationInfo", model);
            }
            return Content("未找到该信息!");
        }

        /// <summary>
        /// 修改合作信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult EditCooperationInfo(bool IsPostBack = true, string IsPerview = "")
        {
            ViewBag.IsPerview = IsPerview;
            VmCooperationInfo model = new VmCooperationInfo();
            try{
            TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                VmB2BInfoPicture p = GetImageInfo();
                string flag = b2bInfoService.UpdateCooperationInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 列表页面
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult CooperationIndex(string state = "3")
        {
            var count = b2bInfoService.GetB2BInfoCount(4);
            ViewBag.CountInfo = count;
            ViewBag.state = state;
            return View();
        }

        /// <summary>
        /// 得到合作列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetCooperationPager(SmCooperation search, int page, int rows)
        {
            var pager = b2bInfoService.GetCooperationPager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 删除合作信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult DeleteCooperation(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetCooperationInfoBy(id);
                vm.Flag = 0;
                string flag = b2bInfoService.UpdateCooperationInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("删除失败");
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 预览合作信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult PreviewCooperationInfo(string EncryptID)
        {
            string DecryptID = Security.Decrypt(EncryptID);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetCooperationInfoBy(id);
                if (vm == null)
                {
                    return Content("未找到该信息");
                }
                return View(vm);
            }
            return Content("未找到该信息");
        }

        /// <summary>
        /// 提交合作信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult ApproveCooperation(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetCooperationInfoBy(id);

                if ((!vm.Flag.HasValue) || vm.Flag != 1)
                {
                    return Content("该信息不能提交");
                }
                else
                {
                    vm.Flag = 2;
                    string flag = b2bInfoService.UpdateCooperationInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("提交失败");
                    }
                }
            }
            return Content("未找到该信息");
        }

        /// <summary>
        /// 刷新信息
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult RefreshCooperationInfo(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetCooperationInfoBy(id);

                if ((!vm.Flag.HasValue) || vm.Flag != 3)
                {
                    return Content("该信息不能刷新");
                }
                else
                {
                    vm.RefreshDate = DateTime.Now;
                    string flag = b2bInfoService.UpdateCooperationInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("刷新失败");
                    }
                }
            }
            return Content("未提到该信息");
        }

        #endregion

        #region 招商信息

        /// <summary>
        /// 添加招商信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult AddCanvassBussinessInfo()
        {
            var enterprise = enterpriseService.GetCurrentEntInfo();
            if (enterprise == null || enterprise.EnterpriseID == 0)
            {
                return Content("<script type='text/javascript'>alert('请先完善企业信息');window.location.href='/My/EntInfo?mid=61'</script>");
            }
            else if (enterprise != null && enterprise.Flag.HasValue && enterprise.Flag == 0)
            {
                return Content("<script type='text/javascript'>alert('企业被冻结请联系管理员');history.back(-1);</script>");
            }
            var count = b2bInfoService.GetB2BInfoCount(3);
            ViewBag.CountInfo = count;
            VmCanvassBussiness model = new VmCanvassBussiness();
            model.EncriptID = "0";
            model.ImageUrl = new List<string>() { "", "", "" };
            model.ImageID = new List<string>() { "", "", "" };
            return View(model);
        }

        /// <summary>
        /// 添加招商信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult AddCanvassBussinessInfo(string EncriptID)
        {
            VmCanvassBussiness model = new VmCanvassBussiness();
            try
            {
                TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                VmB2BInfoPicture p = GetImageInfo();
                string flag = b2bInfoService.AddCanvassBussinessInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 修改招商信息
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult EditCanvassBussinessInfo(string EncryptID, string IsPerview = "")
        {
            var count = b2bInfoService.GetB2BInfoCount(3);
            ViewBag.CountInfo = count;
            ViewBag.IsPerview = IsPerview;
            string decryptID = Fao.Common.Security.Decrypt(EncryptID);
            int id;
            if (int.TryParse(decryptID, out id))
            {
                VmCanvassBussiness model = b2bInfoService.GetCanvassBussinessInfoBy(id);
                if (model.ImageID == null)
                {
                    model.ImageID = new List<string>();
                    model.ImageUrl = new List<string>();
                }
                for (int i = model.ImageID.Count; i < 3; i++)
                {
                    model.ImageID.Add("");
                    model.ImageUrl.Add("");
                }
                //if (model.Flag == 2)
                //{
                //    return Content("该信息不能修改");
                //}
                return View("AddCanvassBussinessInfo", model);
            }
            return Content("未找到该信息!");
        }

        /// <summary>
        /// 修改招商信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult EditCanvassBussinessInfo(bool IsPostBack = true, string IsPerview = "")
        {
            ViewBag.IsPerview = IsPerview;
            VmCanvassBussiness model = new VmCanvassBussiness();
            try
            {
                TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                VmB2BInfoPicture p = GetImageInfo();
                string flag = b2bInfoService.UpdateCanvassBussinessInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 列表页面
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult CanvassBussinessIndex(string state = "3")
        {
            var count = b2bInfoService.GetB2BInfoCount(3);
            ViewBag.CountInfo = count;

            ViewBag.state = state;
            return View();
        }

        /// <summary>
        /// 得到招商列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetCanvassBussinessPager(SmCanvassBussiness search, int page, int rows)
        {
            var pager = b2bInfoService.GetCanvassBussinessPager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 删除招商信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult DeleteCanvassBussiness(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetCanvassBussinessInfoBy(id);
                if (vm != null)
                {
                    vm.Flag = 0;
                    string flag = b2bInfoService.UpdateCanvassBussinessInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("删除失败");
                    }
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 预览招商信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult PreviewCanvassBussinessInfo(string EncryptID)
        {
            string DecryptID = Security.Decrypt(EncryptID);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetCanvassBussinessInfoBy(id);
                if (vm == null)
                {
                    return Content("未找到该信息");
                }
                return View(vm);
            }
            return Content("未找到该信息");
        }

        /// <summary>
        /// 提交招商信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult ApproveCanvassBussiness(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetCanvassBussinessInfoBy(id);

                if ((!vm.Flag.HasValue) || vm.Flag != 1)
                {
                    return Content("该信息不能提交");
                }
                else
                {
                    vm.Flag = 2;
                    string flag = b2bInfoService.UpdateCanvassBussinessInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("提交失败");
                    }
                }
            }
            return Content("未找到该信息");
        }

        /// <summary>
        /// 刷新信息
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult RefreshCanvassBussinessInfo(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetCanvassBussinessInfoBy(id);

                if ((!vm.Flag.HasValue) || vm.Flag != 3)
                {
                    return Content("该信息不能刷新");
                }
                else
                {
                    vm.RefreshDate = DateTime.Now;
                    string flag = b2bInfoService.UpdateCanvassBussinessInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("刷新失败");
                    }
                }
            }
            return Content("未提到该信息");
        }
        #endregion

        #region 代理信息
        /// <summary>
        /// 添加代理信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult AddProxyInfo()
        {
            var enterprise = enterpriseService.GetCurrentEntInfo();
            if (enterprise == null || enterprise.EnterpriseID == 0)
            {
                return Content("<script type='text/javascript'>alert('请先完善企业信息');window.location.href='/My/EntInfo?mid=61'</script>");
            }
            else if (enterprise != null && enterprise.Flag.HasValue && enterprise.Flag == 0)
            {
                return Content("<script type='text/javascript'>alert('企业被冻结请联系管理员');history.back(-1);</script>");
            }
            var count = b2bInfoService.GetB2BInfoCount(5);
            ViewBag.CountInfo = count;
            VmProxy model = new VmProxy();
            model.EncriptID = "0";
            model.ImageUrl = new List<string>() { "", "", "" };
            model.ImageID = new List<string>() { "", "", "" };
            return View(model);
        }

        /// <summary>
        /// 添加代理信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult AddProxyInfo(string EncriptID)
        {
            VmProxy model = new VmProxy();
            try{
            TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                model.Flag = approve != null ? 2 : 1;
                VmB2BInfoPicture p = GetImageInfo();
                string flag = b2bInfoService.AddProxyInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 修改代理信息
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult EditProxyInfo(string EncryptID, string IsPerview = "")
        {
            var count = b2bInfoService.GetB2BInfoCount(5);
            ViewBag.CountInfo = count;
            
            ViewBag.IsPerview = IsPerview;
            string decryptID = Fao.Common.Security.Decrypt(EncryptID);
            int id;
            if (int.TryParse(decryptID, out id))
            {
                VmProxy model = b2bInfoService.GetProxyInfoBy(id);
                if (model.ImageID == null)
                {
                    model.ImageID = new List<string>();
                    model.ImageUrl = new List<string>();
                }
                for (int i = model.ImageID.Count; i < 3; i++)
                {
                    model.ImageID.Add("");
                    model.ImageUrl.Add("");
                }
                //if (model.Flag == 2)
                //{
                //    return Content("该信息不能修改");
                //}
                return View("AddProxyInfo", model);
            }
            return Content("未找到该信息!");
        }

        /// <summary>
        /// 修改代理信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException, HttpPost]
        public ActionResult EditProxyInfo(bool IsPostBack = true, string IsPerview = "")
        {
            ViewBag.IsPerview = IsPerview;
            VmProxy model = new VmProxy();
            try{
            TryUpdateModel(model);
            }
            catch
            { }
            if (ModelState.IsValid)
            {
                string save = Request.Form["Save"];
                string approve = Request.Form["Approve"];
                VmB2BInfoPicture p = GetImageInfo();
                model.Flag = approve != null ? 2 : 1;
                string flag = b2bInfoService.UpdateProxyInfo(model, p);
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }

        /// <summary>
        /// 列表页面
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult ProxyIndex(string state = "3")
        {
            var count = b2bInfoService.GetB2BInfoCount(5);
            ViewBag.CountInfo = count;
            ViewBag.state = state;
            return View();
        }

        /// <summary>
        /// 得到代理列表数据
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult GetProxyPager(SmProxy search, int page, int rows)
        {
            var pager = b2bInfoService.GetProxyPager(search, page, rows);
            return Content(Utils.ToJsonStr(pager));
        }

        /// <summary>
        /// 删除代理信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult DeleteProxy(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetProxyInfoBy(id);
                vm.Flag = 0;
                string flag = b2bInfoService.UpdateProxyInfo(vm);
                if (flag == "1")
                {
                    return Content("1");
                }
                else
                {
                    return Content("删除失败");
                }
            }
            return Content("未提到该信息");
        }

        /// <summary>
        /// 预览代理信息
        /// </summary>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult PreviewProxyInfo(string EncryptID)
        {
            string DecryptID = Security.Decrypt(EncryptID);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetProxyInfoBy(id);
                if (vm == null)
                {
                    return Content("未找到该信息");
                }
                return View(vm);
            }
            return Content("未找到该信息");
        }

        /// <summary>
        /// 提交代理信息
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult ApproveProxy(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetProxyInfoBy(id);

                if ((!vm.Flag.HasValue) || vm.Flag != 1)
                {
                    return Content("该信息不能提交");
                }
                else
                {
                    vm.Flag = 2;
                    string flag = b2bInfoService.UpdateProxyInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("提交失败");
                    }
                }
            }
            return Content("未找到该信息");
        }

        /// <summary>
        /// 刷新信息
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        [ActionLogException]
        public ActionResult RefreshProxyInfo(string eid)
        {
            string DecryptID = Security.Decrypt(eid);
            int id;
            if (int.TryParse(DecryptID, out id))
            {
                var vm = b2bInfoService.GetProxyInfoBy(id);

                if ((!vm.Flag.HasValue) || vm.Flag != 3)
                {
                    return Content("该信息不能刷新");
                }
                else
                {
                    vm.RefreshDate = DateTime.Now;
                    string flag = b2bInfoService.UpdateProxyInfo(vm);
                    if (flag == "1")
                    {
                        return Content("1");
                    }
                    else
                    {
                        return Content("刷新失败");
                    }
                }
            }
            return Content("未提到该信息");
        }
        #endregion

        public ActionResult Attention()
        {
            return View();
        }

        #endregion

        #region 辅助方法

        /// <summary>
        /// 从ModelState返回所有错误信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [NonAction]
        private JsonResult GetError(ModelStateDictionary model)
        {
            List<string> sb = new List<string>();
            //获取所有错误的Key
            List<string> Keys = model.Keys.ToList();
            //获取每一个key对应的ModelStateDictionary
            foreach (var key in Keys)
            {
                var errors = ModelState[key].Errors.ToList();
                //将错误描述添加到sb中
                foreach (var error in errors)
                {
                    sb.Add(error.ErrorMessage);
                }
            }
            return Json(sb);
        }

        /// <summary>
        /// 得到b2b统计信息
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public ContentResult GetCount(int type)
        {
            var count = b2bInfoService.GetB2BInfoCount(type);
            //VmCountInfo count = new VmCountInfo();
            //count.Release = 1;
            //count.Approving = 1;
            //count.NotAdopt = 1;
            //count.Overdue = 1;
            //count.Saving = 1;
            return Content(Utils.ToJsonStr(count));
        }

        /// <summary>
        /// 删除选择信息
        /// </summary>
        /// <param name="chooses"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult DeleteChoose(string chooses)
        {
            if (chooses == null)
            {
                return Content("1");
            }
            var flag = b2bInfoService.DeleteChooses(chooses.Split(','));
            return Content("1");
        }

        /// <summary>
        /// 刷新选中信息
        /// </summary>
        /// <param name="chooses"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult RefreshChoose(string chooses)
        {
            if (chooses == null)
            {
                return Content("1");
            }
            var flag = b2bInfoService.RefreshChooses(chooses.Split(','));
            return Content("1");
        }

        /// <summary>
        /// 提交选中信息
        /// </summary>
        /// <param name="chooses"></param>
        /// <returns></returns>
        [ActionLogException]
        public ContentResult ApproveChoose(string chooses)
        {
            if (chooses == null)
            {
                return Content("1");
            }
            var flag = b2bInfoService.ApproveChooses(chooses.Split(','));
            return Content("1");
        }

        /// <summary>
        /// 上传图片，生成缩略图
        /// </summary>
        /// <returns></returns>
        [ActionLogException]
        public PartialViewResult UploadPicture()
        {

            var file = Request.Files["upalbum"];
            var fid = Request.Form["fid"];
            if (file.ContentLength > 0)
            {
                string imagePath = ConfigurationManager.AppSettings["InfoImagePath"] == null ? "upload/info/" : ConfigurationManager.AppSettings["InfoImagePath"];
                string path = AppDomain.CurrentDomain.BaseDirectory + imagePath;
                string guid = Guid.NewGuid().ToString().Replace("-", "");
                string extensionName = file.FileName.Substring(file.FileName.LastIndexOf("."));
                string newName = guid;
                string fileName = path + "New" + newName + extensionName;
                string smallFileName = guid + "_small.jpg";
                file.SaveAs(fileName);
                //生成缩略图
                ImageHelper.CreateImage(180, 180, fileName, path + smallFileName);
                //加水印
                ImageHelper.DrawWords("New" + newName + extensionName, "金谷高科", 0.8f, ImagePosition.Center, path, guid);
                VmUploadPicture p = new VmUploadPicture();
                p.SmallFileName = smallFileName;
                p.Path = "/" + imagePath;
                p.FileName = "/" + imagePath + newName + ".jpg";
                p.ID = fid == null ? "" : fid;
                p.OriginalName = file.FileName;
                return PartialView("UploadPictureClose", p);
            }
            return PartialView("UploadPictureClose");

        }

        /// <summary>
        /// 得到图片信息
        /// </summary>
        /// <returns></returns>
        private VmB2BInfoPicture GetImageInfo()
        {
            VmB2BInfoPicture picture = new VmB2BInfoPicture();
            picture.OriginalName = new List<string>();
            picture.PictureIDs = new List<string>();
            picture.PictureUrls = new List<string>();
            for (int i = 1; i <= 3; i++)
            {
                var ID = Request.Form["ImageID" + i.ToString()];
                var FileName = Request.Form["ImageURL" + i.ToString()];
                var OriginalName = Request.Form["OriginalName" + i.ToString()];
                picture.OriginalName.Add(OriginalName == "" ? "" : OriginalName);
                picture.PictureIDs.Add(ID == "" ? "" : ID);
                picture.PictureUrls.Add(FileName == "" ? "" : FileName);
            }
            return picture;
        }
        #endregion


        #region 修改资料

        //个人资料
        [ActionLogException]
        public ActionResult UserInfo()
        {
            var userInfo = baseUserService.GetCurrentUserInfo();
            return View(userInfo);
        }

        //修改个人资料
        [ActionLogException, HttpPost]
        public ActionResult UserInfo(string UserID)
        {
            VMUserInfo model = new VMUserInfo();
            try
            {
                TryUpdateModel(model);
            }
            catch { }
            if (ModelState.IsValid)
            {
                string flag = baseUserService.UpadateUserInfo(model);
                if (flag != "1")
                {
                    return Json(new List<string>() { flag });
                }
                return Content(flag);
            }
            else
            {
                return GetError(ModelState);
            }
        }


        //密码管理
        public ActionResult PwdInfo()
        {
            return View();
        }

        //修改密码
        [ActionLogException, HttpPost]
        public ActionResult PwdInfo(string EncriptID)
        {
            VmChangPassword model = new VmChangPassword();
            try
            {
                TryUpdateModel(model);
            }
            catch { }
            if (ModelState.IsValid)
            {
                int flag = baseUserService.ChangPassword("", model.NewPassword, model.OldPassword);
                return Content(flag.ToString());
            }
            else
            {
                return GetError(ModelState);
            }
        }

        //密码管理
        public ActionResult PayPWD()
        {
            return View();
        }

        //修改密码
        [ActionLogException, HttpPost]
        public ActionResult PayPWD(string EncriptID)
        {
            VmPayPWD model = new VmPayPWD();
            try
            {
                TryUpdateModel(model);
            }
            catch { }
            if (ModelState.IsValid)
            {
                int flag = userTransactionService.ChangPayPWD("", model.NewPassword, string.Empty);
                return Content(flag.ToString());
            }
            else
            {
                return GetError(ModelState);
            }
        }

        //公司资料
        [ActionLogException]
        public ActionResult EntInfo()
        {
            var entInfo = enterpriseService.GetCurrentEntInfo();
            return View(entInfo);
        }

        //修改公司资料
        [ActionLogException, HttpPost]
        public ActionResult EntInfo(string EncriptID)
        {
            VMEntInfo model = new VMEntInfo();
            try
            {
                TryUpdateModel(model);
            }
            catch { }
            if (ModelState.IsValid)
            {
                string flag = enterpriseService.UpdateEntInfo(model);
                return Content(flag.ToString());
            }
            else
            {
                return GetError(ModelState);
            }
        }


        [ActionLogException]
        public ActionResult ContactInfo()
        {
            var userInfo = baseUserService.GetCurrentUserInfo();
            return View(userInfo);
        }

        //公司简介
        [ActionLogException]
        public ActionResult EntBriefInfo()
        {
            var userInfo = baseUserService.GetCurrentUserInfo();
            return View(userInfo);
        }
        #endregion

        #region 竞价消费记录
        public ActionResult PPCRecord()
        {
            return View();
        }

        /// <summary>
        /// 获取竞价记录分页数据
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        [HttpPost]
        [ActionLogException]
        public ContentResult PPCRecord(SmPPCRecord sm, int page, int rows)
        {
            var json = Utils.ToJsonStr(ppcService.GetPPCRecordsWithPage(sm, page, rows));
            return Content(json);
        }
        #endregion
    }
}