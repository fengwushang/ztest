﻿/* fao.grid.js 1.0 */

//jump to page number
function jumpPage(id, page) {
    var grid = $('#' + id);
    if (grid.length <= 0) {
        grid = $('.fao_grid');
    }

    //获取grid中的url属性，以请求数据
    var url = grid.attr('url');
    //获取grid中thead标签下的th元素，以绘制列用
    var cols = grid.find('thead th');

    //获取page当前页，以及rows每页行数，post-sm查询传递的json对象 
    var rows = grid.attr('rows');
    var postSm = eval('(' + grid.attr('post-sm') + ')');

    //获取数据源，并绘制表格中的tbody，和tfoot分页。
    faoPost(url + '?page=' + page + "&rows=" + rows, postSm, function (data) {
        renderGrid(grid, data.Rows, cols);
        renderPaging(grid, data.Total, page);
    });
}

function renderGrid(grid, rows, cols) {
    grid.find('tbody').remove();

    //绘制表格数据
    var body = '<tbody>';
    var ft = '';
    var val = '';
    $.each(rows, function (idx, row) {
        body += '<tr>';

        $.each(cols, function (cidx, th) {
            //如果有格式化要求，则优先满足格式化要求
            //td对齐方式 继承th
            var align = $(th).css('text-align');
            if (align && align != '') {
                align = 'style="text-align:' + align + '"';
            }
            else {
                align = '';
            }
            ft = $(th).attr('format');
            val = eval('row.' + $(th).attr('field'));
            if (ft && $.trim(ft) != '') {
                body += '<td ' + align + '>' + eval(ft + '(row,"' + val + '")') + '</td>';
            }
            else {
                body += '<td ' + align + '>' + val + '</td>';
            }

        });

        body += '</tr>';
    });

    body += '</tbody>';
    grid.append(body);

    //绘制完成之后，重写faoGridSuccess获得您想要的效果

    if (typeof (faoGridSuccess) === 'function') {
        faoGridSuccess(grid);
    }


}

function renderPaging(grid, total, currPage) {
    grid.find('tfoot').remove();
    //绘制分页控件
    var tempPN = 1;
    var rows = parseInt(grid.attr('rows'));
    //计算有多少个页
    var pageCount = parseInt(total / rows) + 1;

    //大于15页，显示“第一页，1 2 3 4 5 6 7 8 9，下一页，跳到N页”
    var foot = '<tfoot><tr><td colspan="' + grid.find('thead th').length + '"><div class="pages">';

    if (pageCount > 15) {
        //添加第一页显示在最前端
        foot += '<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id') + '\',1)">首页</a>&nbsp;';

        tempPN = parseInt(currPage);
        if (tempPN > 1) {
            //添加上一页...，为当前选中 -1
            if (tempPN <= 6) {
                foot += '<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id')
                    + '\',1)">上5页</a>...&nbsp;';

            }
            else {
                foot += '<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id') + '\',' + (tempPN - 5)
                    + ')">上5页</a>...&nbsp;';
            }


        }
        //以当前选中为第1个标签，添加5条记录
        for (i = 1; i <= 5; i++) {
            if (pageCount >= tempPN) {
                if (tempPN == currPage) {
                    foot += "<strong>" + tempPN + "</strong>&nbsp;&nbsp;";
                }
                else {
                    foot += '<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id') + '\',' + tempPN + ')">'
                        + tempPN + '</a>&nbsp;&nbsp;';
                }
                tempPN += 1;
            }
        }
        if (pageCount >= tempPN) {
            //添加下一页...，为当前选中 +1
            foot += '...<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id') + '\',' + tempPN + ')">下5页</a>&nbsp;';
        }
        //始终显示最后一页页码
        foot += '...<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id') + '\',' + pageCount + ')">' + pageCount + '页</a>&nbsp;';

        //添加跳转到第几页
        foot += '<input style="width:50px;" id="go" value="' + currPage + '" /><a  href="javascript:void(0);" onclick="goPage(\'' + grid.attr('id') + '\')">GO</a>&nbsp;';
    }
    else {

        for (i = 1; i <= total; i = i + rows) {
            if (tempPN == currPage) {
                foot += "<strong>" + tempPN + "</strong>&nbsp;&nbsp;";
            }
            else {
                foot += '<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id') + '\',' + tempPN + ')">' + tempPN + '</a>&nbsp;&nbsp;';
            }
            tempPN += 1;
        }
    }

    foot += '总记录数：' + total + '</div></td></tr></tfoot>';

    grid.append(foot);
}
function goPage(id) {
    jumpPage(id, parseInt($('#go').val()));

}

function loadGrid(id) {

    var grid = $('#' + id);
    if (grid.length <= 0) {
        grid = $('.fao_grid');
    }
    //获取grid中的url属性，以请求数据
    var url = grid.attr('url');
    //获取grid中thead标签下的th元素，以绘制列用
    var cols = grid.find('thead th');

    //如果上述条件没有设定，则弹出提示
    if (!url || cols.length <= 0) {
        return;
    }
    //获取page当前页，以及rows每页行数，post-sm查询传递的json对象
    var page = grid.attr('page');
    var rows = grid.attr('rows');
    var postSm = eval('(' + grid.attr('post-sm') + ')');

    //获取数据源，并绘制表格中的tbody，和tfoot分页。
    faoPost(url + '?page=' + page + "&rows=" + rows, postSm, function (data) {
        renderGrid(grid, data.Rows, cols);
        if (page && rows) {
            renderPaging(grid, data.Total, page);
        }

        //表格鼠标移动行变色
        $('.fao_grid tr').mouseover(function () {
            $(this).css('color', '#2b5788');
        }).mouseout(function () {
            $(this).css('color', '');
        });

        //获得全选按钮
        var first = $('.fao_grid input:checkbox').eq(0);

        //单行checkbox选中行变色
        $('.fao_grid input:checkbox').click(function () {

            var val = $(this).val();
            //判断是否是全选按钮
            if (val && val != 'on' && val != '') {
                if (this.checked) {
                    $(this).parent().parent().css('background-color', '#ededed');
                }
                else {
                    $(this).parent().parent().css('background-color', '');
                }

                //得到选中项总数
                var num = 0;
                $(".fao_grid tbody input:checkbox").each(function () {
                    if (this.checked) {
                        num += 1;
                    }
                })
                //判断选中项总数与选项总数是否一致
                if (num == data.Rows.length) {
                    //一致 全选选中
                    $('.fao_grid input:checkbox').eq(0).each(function () {
                        this.checked = true;
                        $(this).parent().parent().css('background-color', '#ededed');
                    });
                } else {
                    //不一致 全选取消
                    $('.fao_grid input:checkbox').eq(0).each(function () {
                        this.checked = false;
                        $(this).parent().parent().css('background-color', '');
                    });
                }
            }

        });
    });
}


function faoGrid() {

    var grids = $('.fao_grid');
    if (grids.length <= 0) {
        return;
    }
    for (i = 0; i < grids.length; i++) {

        loadGrid($(grids[i]).attr('id'));
    }
}

/* end; faogrid with paging */

$(function () {
    faoGrid();
})
//全选事件
function checkAll(sender) {
    var boxs = $('.fao_grid input:checkbox');
    boxs.each(function () {
        this.checked = sender.checked;
    });
    if (sender.checked) {
        $('.fao_grid tr').css('background-color', '#ededed');
    }
    else {
        $('.fao_grid tr').css('background-color', '');
    }
    $('.fao_grid tfoot tr').css('background-color', '');
}