﻿/* fao.ajax.js 1.0 */
//调用faoPost实现异步提交操作，并返回json数据。
function faoPost(url, data, suc) {
    $.ajax({
        type: "POST",
        url: url,
        data: data,
        dataType: "json"
    }).done(function (data) {
        suc(data);
    });
}

//调用faoPost2实现异步提交操作，并返回json数据。
//可以实现按钮提交表单一些效果展示
function faoPost2(url, data, btnID, suc) {

    $('#' + btnID).attr('disabled', 'disabled');
    $.ajax({
        type: "POST",
        url: url,
        data: data,
        dataType: "json"
    }).done(function (data) {
        $('#' + btnID).removeAttr('disabled');
        suc(data);
    });
}

//调用faoGet实现异步获取数据，返回json数据。
function faoGet(url, suc) {
    $.ajax({
        type: "GET",
        url: url,
        dataType: "json",
        cache: false,
        success: suc
    });
}
