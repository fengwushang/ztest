﻿//简写获取节点byId
function id(a) {
    return document.getElementById(a);
}
//简写获取节点byTagName
function tag(a) {
    return document.getElementsByTagName(a);
}

//简写创建元素节点
function newTag(a) {
    return document.createElement(a);
}
//简写创建文本节点
function newText(a) {
    return document.createTextNode(a);
}
//----------------------------------------------------------------------
//创建一些全局变量
var divStars;//定义星星所在div
var oGrayStar = Array(5);//创建star数组
//页面onload后要执行的
window.onload = loadImg;//页面载入后创建5个灰色五角星
//创建灰色星星
function createGrayStar(i) {
    oGrayStar[i] = newTag("img");
    oGrayStar[i].src = "/Content/images/star3.gif";
    oGrayStar[i].alt = (i + 1) + "分";
    oGrayStar[i].onclick = function () { changeState(i, 0) };
    oGrayStar[i].onmouseover = function () { changeState(i, 1) };
    oGrayStar[i].onmouseout = function () { changeState(i, 2) };
    return oGrayStar[i];
}
function abc() { alert("12345") }
//创建五个灰色五角星
function loadImg() {
    divStars = id("divStars");
    for (i = 0; i < 5; i++) {
        divStars.appendChild(createGrayStar(i));
    }
    createComment();
}
//当前索引值以前的星星变为红色星星
function changeToRedStar(i) {
    for (j = 0; j <= i; j++) {
        oGrayStar[j].src = "images/star4.gif";
    }
}
//所有星星变为灰色星星
function changeToGrayStar() {
    for (j = 0; j < 5; j++) {
        oGrayStar[j].src = "images/star3.gif";
    }
}

var i1, j1, k1 = null;//onclick为i，onmouseover为j,onmouseout为j
//定义三种状态（点击、鼠标滑过、鼠标移出）时的索引变量，并创建事件函数
function changeState(index, tag) {
    if (tag == 0) {
        i1 = index;
        changeToRedStar(i1);
        replaceComment(i1);
    }
    else if (tag == 1) {
        j1 = index;
        changeToGrayStar();
        changeToRedStar(j1);
        replaceComment(j1);
    }
    else if (tag == 2) {
        k1 = i1;
        changeToGrayStar();
        changeToRedStar(k1);
        replaceComment(k1);
    }
}
//创建评论文字
var str = ["不喜欢", "一般", "推荐", "喜欢", "非常喜欢"];//评论字符串
var oNewSpan;//新span容器
var oNewText;//当前文本节点

//创建带空格文本的span
function createComment() {
    oNewSpan = newTag("span");
    oNewText = newText("");
    oNewSpan.appendChild(oNewText);
    divStars.appendChild(oNewSpan);
}
//替换新评论
function replaceComment(index) {
    if (index || index == 0) {
        oNewText = newText(str[index]);
        document.getElementById("sp_vl").innerText = index + 1;
    }
    else {
        oNewText = newText("");
        document.getElementById("sp_vl").innerText = 0;
    }
    oNewSpan.replaceChild(oNewText, oNewSpan.firstChild);
}
