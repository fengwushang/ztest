﻿//获取url参数
function urlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

//调用faoPost实现异步提交操作，并返回json数据。
function faoPost(url, data, suc) {
    $.ajax({
        type: "POST",
        url: url,
        data: data,
        dataType: "json"
    }).done(suc);
}

//调用faoPost2实现异步提交操作，并返回json数据。
//可以实现按钮提交表单一些效果展示
function faoPost2(url, data, btnID, suc) {

    $('#' + btnID).attr('disabled', 'disabled');
    $.ajax({
        type: "POST",
        url: url,
        data: data,
        dataType: "json"
    }).done(function (data) {

        suc(data);
        $('#' + btnID).removeAttr('disabled');
    });
}

//调用faoGet实现异步获取数据，返回json数据。
function faoGet(url, suc) {
    $.ajax({
        type: "GET",
        url: url,
        dataType: "json",
        cache: false,
        success: suc
    });
}


//加关注，添加class="fao_attention"，data-id="{密文id}"以实现加关注功能。
function addFaoAttention(th) {

    var param = $(th).parent().attr('data-id');

    faoGet('/home/addAttention/' + param, function (data) {
        alert(data.msg);
    });

}

//加好友，添加class="fao_friend"，data-id="{密文id}"以实现加好友功能。
function addFaoFriend(th) {

    var param = $(th).parent().attr('data-id');

    faoGet('/home/addFriend/' + param, function (data) {
        alert(data.msg);
    });

}

/* faogrid with paging */

function jumpPage(id, page) {
    var grid = $('#' + id);
    if (grid.length <= 0) {
        grid = $('.fao_grid');
    }

    //获取grid中的url属性，以请求数据
    var url = grid.attr('url');
    //获取grid中thead标签下的th元素，以绘制列用
    var cols = grid.find('thead th');

    //获取page当前页，以及rows每页行数，post-sm查询传递的json对象 
    var rows = grid.attr('rows');
    var postSm = eval('(' + grid.attr('post-sm') + ')');

    //获取数据源，并绘制表格中的tbody，和tfoot分页。
    faoPost(url + '?page=' + page + "&rows=" + rows, postSm, function (data) {
        renderGrid(grid, data.rows, cols);
        renderPaging(grid, data.total, page);
    });
}

function renderGrid(grid, rows, cols) {
    grid.find('tbody').remove();

    //绘制表格数据
    var body = '<tbody>';
    var ft = '';
    var val = '';
    $.each(rows, function (idx, row) {
        body += '<tr>';

        $.each(cols, function (cidx, th) {
            //如果有格式化要求，则优先满足格式化要求
            ft = $(th).attr('format');
            val = eval('row.' + $(th).attr('field'));
            if (ft && $.trim(ft) != '') {
                body += '<td>' + eval(ft + '(row,"' + val + '")') + '</td>';
            }
            else {
                body += '<td>' + val + '</td>';
            }

        });

        body += '</tr>';
    });

    body += '</tbody>';
    grid.append(body);
}

function renderPaging(grid, total, currPage) {
    grid.find('tfoot').remove();
    //绘制分页控件
    var tempPN = 1;
    var rows = parseInt(grid.attr('rows'));
    //计算有多少个页
    var pageCount = parseInt(total / rows) + 1;

    //大于15页，显示“第一页，1 2 3 4 5 6 7 8 9，下一页，跳到N页”
    var foot = '<tfoot><tr><td colspan="' + grid.find('thead th').length + '"><div class="pages">';
  
    if (pageCount > 15) {
        //添加第一页显示在最前端
        foot += '<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id') + '\',1)">首页</a>&nbsp;';

        tempPN = parseInt( currPage);
        if (tempPN > 1) {
            //添加上一页...，为当前选中 -1
            if (tempPN <= 6) {
                foot += '<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id')
                    + '\',1)">上一页</a>...&nbsp;';

            }
            else {
                foot += '<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id') + '\',' + (tempPN - 5)
                    + ')">上一页</a>...&nbsp;';
            }


        }
        //以当前选中为第1个标签，添加5条记录
        for (i = 1; i <= 5; i++) {
            if (pageCount >= tempPN) {
                if (tempPN == currPage) {
                    foot += "<strong>" + tempPN + "</strong>&nbsp;&nbsp;";
                }
                else {
                    foot += '<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id') + '\',' + tempPN + ')">'
                        + tempPN + '</a>&nbsp;&nbsp;';
                }
                tempPN += 1;
            }
        }
        if (pageCount >= tempPN) {
            //添加下一页...，为当前选中 +1
            foot += '...<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id') + '\',' + tempPN + ')">下一页</a>&nbsp;';
        }

        //添加跳转到对少页
        foot += '<input style="width:50px;" id="go" value="' + currPage + '" /><a  href="javascript:void(0);" onclick="goPage(\'' + grid.attr('id') + '\')">GO</a>&nbsp;';
    }
    else {

        for (i = 1; i <= total; i = i + rows) {
            if (tempPN == currPage) {
                foot += "<strong>" + tempPN + "</strong>&nbsp;&nbsp;";
            }
            else {
                foot += '<a href="javascript:void(0);" onclick="jumpPage(\'' + grid.attr('id') + '\',' + tempPN + ')">' + tempPN + '</a>&nbsp;&nbsp;';
            }
            tempPN += 1;
        }
    }
    
    foot += '<cite>总记录数：' + total + '</cite></div></td></tr></tfoot>';
     
    grid.append(foot);

    if ($('#All')) {
        $('#All').removeAttr("checked");
    }
}
function goPage(id) {
    jumpPage(id,parseInt($('#go').val()));
}

function loadGrid(id) {

    var grid = $('#' + id);
    if (grid.length <= 0) {
        grid = $('.fao_grid');
    }
    //获取grid中的url属性，以请求数据
    var url = grid.attr('url');
    //获取grid中thead标签下的th元素，以绘制列用
    var cols = grid.find('thead th');

    //如果上述条件没有设定，则弹出提示
    if (!url || cols.length <= 0) {
        alert('请设置id：' + id + '的url，thead>th，等属性');
    }
    //获取page当前页，以及rows每页行数，post-sm查询传递的json对象
    var page = grid.attr('page');
    var rows = grid.attr('rows');
    var postSm = eval('(' + grid.attr('post-sm') + ')');

    //获取数据源，并绘制表格中的tbody，和tfoot分页。
    faoPost(url + '?page=' + page + "&rows=" + rows, postSm, function (data) {
        renderGrid(grid, data.rows, cols);
        if (page && rows) {
            renderPaging(grid, data.total, page);


        }

    });
}


function faoGrid() {

    var grids = $('.fao_grid');
    if (grids.length <= 0) {
        return;
    }
    for (i = 0; i < grids.length; i++) {

        loadGrid($(grids[i]).attr('id'));
    }


}

/* get the url query */
function GetQueryString(str) {
    var LocString = String(window.document.location.href);
    var rs = new RegExp("(^|)" + str + "=([^\&]*)(\&|$)", "gi").exec(LocString), tmp;
    if (tmp = rs) return decodeURIComponent(tmp[2]);
    return "";
}


/* end; faogrid with paging */

//初始化页面设置
$(function () {
    //加关注，添加class="fao_attention"
    //$('.fao_attention').append('<img src="/Content/Images/jgz.jpg" onclick="addFaoAttention(this);" />');
    //加好友，添加class="fao_friend"
    //$('.fao_friend').append('<img src="/Content/Images/jhy.jpg" onclick="addFaoFriend(this);" />');

    //门户页面表格，添加class="fao_grid"
    faoGrid();

});

