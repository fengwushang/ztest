﻿
var isIE = (document.all && window.ActiveXObject && !window.opera) ? true : false;

if (isIE) try { document.execCommand("BackgroundImageCache", false, true); } catch (e) { }


function Dd(i) { return document.getElementById(i); }
function Ds(i) { Dd(i).style.display = ''; }
function Dh(i) { Dd(i).style.display = 'none'; }
function Df(i) { Dd(i).focus(); }

function m(i) { try { Dd(i).className = 'tab_on'; } catch (e) { } }
function s(i) { try { Dd(i).className = 'side_b'; } catch (e) { } }
function v(i) { if (Dd(i).className == 'side_a') Dd(i).className = 'side_c'; }
function t(i) { if (Dd(i).className == 'side_c') Dd(i).className = 'side_a'; }
function c(i, s) {
    var s = s ? '_' + s : '';
    if (Dd('I_' + i).src.indexOf('arrow_c') == -1) {
        Dd('I_' + i).src = '/Content/Images/arrow_c' + s + '.gif'; Ds('D_' + i);
    } else {
        Dd('I_' + i).src = '/Content/Images/arrow_o' + s + '.gif'; Dh('D_' + i);
    }
    for (var j = 0; j < 6; j++) {
        if (j != i) {
            try { Dd('I_' + j).src = '/Content/Images/arrow_o' + s + '.gif'; Dh('D_' + j); } catch (e) { }
        }
    }
}
var n = 1
function o() {
    for (var j = 0; j < 6; j++) {
        if (n == 1) {
            try { Dd('I_' + j).src = '/Content/Images/arrow_c.gif'; Ds('D_' + j); } catch (e) { }
        } else {
            try { Dd('I_' + j).src = '/Content/Images/arrow_o.gif'; Dh('D_' + j); } catch (e) { }
        }
    }
    if (n == 1) { n = 0; } else { n = 1; }
}
function oh(o) {
    if (o.className == 'side_h') {
        Dh('side'); o.className = 'side_s';
        
    } else {
        Ds('side'); o.className = 'side_h';
         
    }
}
function sh(c) {
    if (Dd('head_kw').value == L['keyword_value'] || Dd('head_kw').value.length < 1) {
         
        Dd('head_kw').focus();
        return false;
    }
    if (c) Dd('head_sh').submit();
}
//绘制字典选项
function readerSelectDictionary(th) {
    faoGet('/back/Dicts/?abb=' + th.attr('id'), function (data) {
        var select = '<select>';
        select += '<option value="0">请选择</option>';
        $.each(data, function (idx, row) {
            select += '<option value="' + row.ItemID + '">' + row.ItemName + '</option>';
        });
        select += '</select>';

        th.append(select);

    });

}