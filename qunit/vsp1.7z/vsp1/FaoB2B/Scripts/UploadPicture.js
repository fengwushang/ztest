﻿//文件上传
function delAlbum(i, s) {
    $('#thumb' + i).val("");
    $('#showthumb' + i).attr("src", "/Content/Images/waitpic.gif");
}

function Dalbum(f,s) {
    var DTPath = "";
    var s = s ? 'none' : ''; var c = '<iframe name="UploadAlbum" style="display:none" src=""></iframe>';
    c += '<form method="post" target="UploadAlbum" enctype="multipart/form-data" action="/My/UploadPicture" onsubmit="return isUP(\'upalbum\');">' +
            '<input type="hidden" name="fid" value="' + f + '"/>' +
            '<table cellpadding="3">' +
                '<tr id="local_url">' +
                    '<td>' +
                        '<input id="upalbum" type="file" size="20" name="upalbum" onchange="if(isImg(\'upalbum\')){this.form.submit();Dd(\'Dsubmit\').disabled=true;Dd(\'Dsubmit\').value=\'' + '上传中..' + '\';}"/>' +
                    '</td>' +
                '</tr>' +
                '<tr><td><input type="submit" class="btn" value="上传" id="Dsubmit"/>' +
                '&nbsp;&nbsp;' +
                '<input type="button" class="btn" value="取消" onclick="cDialog();"/></td></tr>' +
            '</table>' +
          '</form>';
    mkDialog('', c, '上传图片', 250);
}

function isUP(i) {
    return isImg(i);
}

function isImg(i, e) {
    var v = $("#" + i).val();
    if (v == '') { confirm('请选择文件'); return false; }
    var t = ext(v);
    t = t.toLowerCase();
    var a = typeof e == 'undefined' ? 'jpg|gif|png|jpeg|bmp' : e;
    if (a.length > 2 && a.indexOf(t) == -1) { confirm('限制为:' + a); return false; }
    return true;
}

function cDialog() {
    sDialog('Dtop', 100, '-');
}

function sDialog(i, v, t) {
    if (t == '+') {
        if (isIE) { $("#" + i).css("filter", "Alpha(Opacity=" + v + ")"); } else { $("#" + i).css("opacity:", (v / 100)); }
        if (v == 100) { Eh(); return; }
        if (v + 25 < 100) { window.setTimeout(function () { sDialog(i, v + 25, t); }, 1); } else { sDialog(i, 100, t); }
    } else {
        try { $("#" + i).hide(); document.body.removeChild($('#Dtop')[0]); $('#Dmid').hide(); document.body.removeChild($('#Dmid')[0]); Es(); } catch (e) { }
    }
}

function Es(t) {
    var t = t ? t : 'select';
    if (isIE) {
        var arVersion = navigator.appVersion.split("MSIE"); var IEversion = parseFloat(arVersion[1]);
        if (IEversion >= 7 || IEversion < 5) return;
        var ss = document.body.getElementsByTagName(t);
        for (var i = 0; i < ss.length; i++) { ss[i].style.visibility = 'visible'; }
    }
}

function Eh(t) {
    var t = t ? t : 'select';
    if (isIE) {
        var arVersion = navigator.appVersion.split("MSIE"); var IEversion = parseFloat(arVersion[1]);
        if (IEversion >= 7 || IEversion < 5) return;
        var ss = document.body.getElementsByTagName(t);
        for (var i = 0; i < ss.length; i++) { ss[i].style.visibility = 'hidden'; }
    }
}
function ext(v) { return v.substring(v.lastIndexOf('.') + 1, v.length); }
var isIE = (document.all && window.ActiveXObject && !window.opera) ? true : false;
var isGecko = navigator.userAgent.indexOf('WebKit') != -1;

function mkDialog(u, c, t, w, s, p, px, py) {
    var w = w ? w : 300;
    var u = u ? u : '';
    var c = c ? c : (u ? '<iframe src="' + u + '" width="' + (w - 25) + '" height="0" border="0" vspace="0" hspace="0" marginwidth="0" marginheight="0" framespacing="0" frameborder="0" scrolling="no"></iframe>' : '');
    var t = t ? t : '系统提示';
    var s = s ? s : 0;
    var p = p ? p : 0;
    var px = px ? px : 0;
    var py = py ? py : 0;
    var body = document.documentElement || document.body;
    if (isGecko) body = document.body;
    var cw = body.clientWidth;
    var ch = body.clientHeight;
    var bsw = body.scrollWidth;
    var bsh = body.scrollHeight;
    var bw = parseInt((bsw < cw) ? cw : bsw);
    var bh = parseInt((bsh < ch) ? ch : bsh);
    if (!s) {
        var Dmid = document.createElement("div");
        with (Dmid.style) { zIndex = 998; position = 'absolute'; width = '100%'; height = bh + 'px'; overflow = 'hidden'; top = 0; left = 0; border = "0px"; backgroundColor = '#EEEEEE'; if (isIE) { filter = " Alpha(Opacity=50)"; } else { opacity = 50 / 100; } }
        Dmid.id = "Dmid";
        document.body.appendChild(Dmid);
    }
    var sl = px ? px : body.scrollLeft + parseInt((cw - w) / 2);
    var st = py ? py : body.scrollTop + parseInt(ch / 2) - 100;
    var Dtop = document.createElement("div");
    with (Dtop.style) { zIndex = 999; position = 'absolute'; width = w + 'px'; left = sl + 'px'; top = st + 'px'; if (isIE) { filter = " Alpha(Opacity=0)"; } else { opacity: 1 } }
    Dtop.id = 'Dtop';
    document.body.appendChild(Dtop);
    document.getElementById('Dtop').innerHTML = '<div class="dbody"><div class="dhead" ondblclick="cDialog();" onselectstart="return false;"><span onclick="cDialog();">&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;' + t + '</div><div class="dbox">' + c + '</div></div>';
    sDialog('Dtop', 100, '+');
}
function delAlbum(i, s) { document.getElementById('ImageURL' + i).value = ''; document.getElementById('showthumb' + i).src = '/Content/Images/waitpic.gif'; }